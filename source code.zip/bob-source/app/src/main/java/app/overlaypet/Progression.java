package app.overlaypet;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/** On-device XP and a date-selected set of four quests from a generated 1,000-quest pool. */
final class Progression {
    static final String ENABLED = "progression_enabled";
    private static final String XP = "progression_xp";
    private static final String DAY = "progression_local_day";
    private static final String DAY_XP = "progression_day_xp";
    private static final String LAST_FEED = "progression_last_feed";
    private static final String LAST_PLAY = "progression_last_play";
    private static final String LAST_REQUEST = "progression_last_request";
    private static final String LAST_HAT = "progression_last_hat";
    private static final String[] QUEST_PROGRESS = {
        "quest_progress_feed", "quest_progress_play", "quest_progress_trick", "quest_progress_mega"
    };
    private static final String[] QUEST_VARIANTS = {
        "quest_variant_feed", "quest_variant_play", "quest_variant_trick", "quest_variant_mega"
    };
    private static final String QUEST_DONE = "quest_done_mask";
    private static final String MEGA_STREAK = "quest_mega_streak";
    private static final int DAILY_CAP = 60;
    private static final int LEVEL_XP = 100;
    private static final Quest[][] POOL = createPool();
    private final SharedPreferences prefs;

    Progression(Context context) { prefs = Accessory.preferences(context); }

    int xp() { ensureLocalDay(); return prefs.getInt(XP, 0); }
    int level() { return xp() / LEVEL_XP + 1; }
    int intoLevel() { return xp() % LEVEL_XP; }
    int remainingToday() {
        ensureLocalDay();
        return Math.max(0, DAILY_CAP - prefs.getInt(DAY_XP, 0));
    }

    boolean award(String action, int amount, long cooldownMs) {
        if (!prefs.getBoolean(ENABLED, false)) return false;
        ensureLocalDay();
        long now = System.currentTimeMillis();
        String stampKey;
        switch (action) {
            case "feed": stampKey = LAST_FEED; break;
            case "play": stampKey = LAST_PLAY; break;
            case "request": stampKey = LAST_REQUEST; break;
            case "hat": stampKey = LAST_HAT; break;
            default: return false;
        }
        if (now - prefs.getLong(stampKey, 0) < cooldownMs) return false;
        int dayXp = prefs.getInt(DAY_XP, 0);
        int earned = Math.min(Math.max(0, amount), DAILY_CAP - dayXp);
        if (earned <= 0) return false;
        prefs.edit().putLong(stampKey, now).putInt(DAY_XP, dayXp + earned)
                .putInt(XP, prefs.getInt(XP, 0) + earned).apply();
        unlockRewards();
        return true;
    }

    void recordFeed() { recordQuestAction(0); }
    void recordPlay() { recordQuestAction(1); }

    private void recordQuestAction(int slot) {
        if (!prefs.getBoolean(ENABLED, false)) return;
        ensureLocalDay();
        incrementQuest(slot, 1);
    }

    /** One successful bounced throw advances normal trickshots and the consecutive Mega Quest. */
    void recordTrickshot(int wallContacts, boolean inUpperZone) {
        if (!prefs.getBoolean(ENABLED, false)) return;
        ensureLocalDay();
        if (wallContacts < 1) {
            resetTrickshotStreaks();
            return;
        }
        award("hat", 10, 12 * 60 * 60_000L);
        incrementQuest(2, 1);
        if (inUpperZone) {
            int streak = prefs.getInt(MEGA_STREAK, 0) + 1;
            prefs.edit().putInt(MEGA_STREAK, streak).apply();
            setQuestProgress(3, streak);
        } else {
            resetMegaStreak();
        }
    }

    /** A thrown hat that misses Bob breaks the Mega Quest sequence. */
    void failTrickshot() {
        if (!prefs.getBoolean(ENABLED, false)) return;
        ensureLocalDay();
        resetTrickshotStreaks();
    }

    private void resetTrickshotStreaks() {
        int done = prefs.getInt(QUEST_DONE, 0);
        SharedPreferences.Editor edit = prefs.edit();
        if ((done & (1 << 2)) == 0) edit.putInt(QUEST_PROGRESS[2], 0);
        if ((done & (1 << 3)) == 0) edit.putInt(MEGA_STREAK, 0).putInt(QUEST_PROGRESS[3], 0);
        edit.apply();
    }

    private void resetMegaStreak() {
        if ((prefs.getInt(QUEST_DONE, 0) & (1 << 3)) != 0) return;
        prefs.edit().putInt(MEGA_STREAK, 0).putInt(QUEST_PROGRESS[3], 0).apply();
    }

    private void incrementQuest(int slot, int amount) {
        if ((prefs.getInt(QUEST_DONE, 0) & (1 << slot)) != 0) return;
        Quest quest = dailyQuest(slot);
        int next = Math.min(quest.target, prefs.getInt(QUEST_PROGRESS[slot], 0) + amount);
        setQuestProgress(slot, next);
    }

    private void setQuestProgress(int slot, int progress) {
        Quest quest = dailyQuest(slot);
        int next = Math.min(quest.target, Math.max(0, progress));
        int done = prefs.getInt(QUEST_DONE, 0);
        SharedPreferences.Editor edit = prefs.edit().putInt(QUEST_PROGRESS[slot], next);
        if (next >= quest.target && (done & (1 << slot)) == 0) {
            edit.putInt(QUEST_DONE, done | (1 << slot));
            addXp(slot == 3 ? 15 : 10);
        }
        edit.apply();
    }

    private void addXp(int amount) {
        int dayXp = prefs.getInt(DAY_XP, 0);
        int earned = Math.min(amount, Math.max(0, DAILY_CAP - dayXp));
        if (earned <= 0) return;
        prefs.edit().putInt(DAY_XP, dayXp + earned)
                .putInt(XP, prefs.getInt(XP, 0) + earned).apply();
        unlockRewards();
    }

    String taskName(int slot) { ensureLocalDay(); return dailyQuest(slot).name; }
    int taskTarget(int slot) { ensureLocalDay(); return dailyQuest(slot).target; }
    int taskReward(int slot) { return slot == 3 ? 15 : 10; }
    int taskProgress(int slot) {
        ensureLocalDay();
        return prefs.getInt(QUEST_PROGRESS[slot], 0);
    }
    boolean taskDone(int slot) {
        ensureLocalDay();
        return (prefs.getInt(QUEST_DONE, 0) & (1 << slot)) != 0;
    }
    int questPoolSize() { return 1000; }

    private Quest dailyQuest(int slot) {
        int variant = prefs.getInt(QUEST_VARIANTS[slot], legacyVariant(prefs.getInt(DAY, dayKey()), slot));
        return POOL[slot][variant];
    }

    private static int legacyVariant(int day, int slot) {
        return Math.floorMod(day * 1_103_515_245 + slot * 12_345_679, 250);
    }

    private static Quest[][] createPool() {
        String[] adjectives = {
            "Sunny", "Sleepy", "Bouncy", "Cozy", "Merry", "Cosmic", "Doodle", "Lucky", "Gentle", "Wiggly"
        };
        String[] nouns = {
            "Picnic", "Puddle", "Comet", "Pancake", "Meadow", "Marble", "Cloud", "Button", "Biscuit", "Lantern",
            "Poppy", "Pebble", "Jellybean", "Raindrop", "Acorn", "Firefly", "Muffin", "Dandelion", "Ribbon", "Sundae",
            "Moonbeam", "Tumble", "Sprout", "Confetti", "Teacup"
        };
        Quest[][] quests = new Quest[4][250];
        for (int variant = 0; variant < 250; variant++) {
            String theme = adjectives[variant / 25] + " " + nouns[variant % 25];
            int feedTarget = 1 + variant % 5;
            int playTarget = 1 + (variant / 5) % 5;
            int trickTarget = 1 + (variant / 3) % 3;
            quests[0][variant] = new Quest(theme + ": feed Bob " + feedTarget
                    + (feedTarget == 1 ? " snack" : " snacks"), feedTarget);
            quests[1][variant] = new Quest(theme + ": play with Bob " + playTarget
                    + (playTarget == 1 ? " time" : " times"), playTarget);
            quests[2][variant] = new Quest(theme + ": land " + trickTarget
                    + (trickTarget == 1 ? " bounced trickshot" : " bounced trickshots in a row"), trickTarget);
            quests[3][variant] = new Quest("Mega Quest · " + theme
                    + ": land 2 trickshots in a row in the upper area", 2);
        }
        return quests;
    }

    private static final class Quest {
        final String name;
        final int target;
        Quest(String name, int target) { this.name = name; this.target = target; }
    }

    private void ensureLocalDay() {
        int today = dayKey();
        int previousDay = prefs.getInt(DAY, -1);
        boolean sameDay = previousDay == today;
        boolean variantsSaved = true;
        for (String key : QUEST_VARIANTS) variantsSaved &= prefs.contains(key);
        if (sameDay && variantsSaved) return;

        Random daily = new Random((((long) today) << 32) ^ 0x6a09e667f3bcc909L);
        SharedPreferences.Editor edit = prefs.edit().putInt(DAY, today);
        for (int slot = 0; slot < QUEST_VARIANTS.length; slot++) {
            int previousVariant = previousDay < 0 ? -1
                    : prefs.getInt(QUEST_VARIANTS[slot], legacyVariant(previousDay, slot));
            int variant = daily.nextInt(POOL[slot].length);
            if (previousVariant >= 0) {
                Quest previous = POOL[slot][Math.floorMod(previousVariant, POOL[slot].length)];
                for (int attempt = 0; attempt < POOL[slot].length
                        && POOL[slot][variant].name.equals(previous.name); attempt++) {
                    variant = (variant + 1) % POOL[slot].length;
                }
            }
            edit.putInt(QUEST_VARIANTS[slot], variant);
        }
        if (!sameDay) {
            edit.putInt(DAY_XP, 0).putInt(QUEST_DONE, 0).putInt(MEGA_STREAK, 0)
                    .putInt(QUEST_PROGRESS[0], 0).putInt(QUEST_PROGRESS[1], 0)
                    .putInt(QUEST_PROGRESS[2], 0).putInt(QUEST_PROGRESS[3], 0);
        }
        edit.apply();
    }

    private static int dayKey() {
        Calendar local = Calendar.getInstance();
        return local.get(Calendar.YEAR) * 10000
                + (local.get(Calendar.MONTH) + 1) * 100
                + local.get(Calendar.DAY_OF_MONTH);
    }

    String title() {
        int level = level();
        if (level >= 20) return "Bob Legend";
        if (level >= 10) return "Best Bud";
        if (level >= 5) return "Snack Buddy";
        return "Tiny Pal";
    }

    void unlockRewards() {
        Set<String> owned = new HashSet<>(prefs.getStringSet(
                "unlocked_accessories", java.util.Collections.singleton("HAT")));
        for (Accessory accessory : Accessory.values()) {
            if (accessory != Accessory.NONE && level() >= accessory.unlockLevel) {
                owned.add(accessory.name());
            }
        }
        prefs.edit().putStringSet("unlocked_accessories", owned).apply();
    }
}
