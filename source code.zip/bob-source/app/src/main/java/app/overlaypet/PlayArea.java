package app.overlaypet;

import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.Display;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;

final class PlayArea {
    private static final Rect cachedBounds = new Rect();
    private static int cachedDisplay = -1;
    private static int cachedRotation = -1;

    private PlayArea() {}

    static void measure(View view, Rect out) {
        if (Build.VERSION.SDK_INT >= 30) {
            Display display = view.getDisplay();
            int id = display == null ? -1 : display.getDisplayId();
            int rotation = display == null ? -1 : display.getRotation();
            if (cachedBounds.isEmpty() || id != cachedDisplay || rotation != cachedRotation) {
                WindowManager manager = view.getContext().getSystemService(WindowManager.class);
                WindowMetrics metrics = manager.getMaximumWindowMetrics();
                Insets reserved = metrics.getWindowInsets().getInsetsIgnoringVisibility(reservedTypes());
                cachedBounds.set(metrics.getBounds());
                cachedBounds.inset(reserved.left, reserved.top, reserved.right, reserved.bottom);
                cachedDisplay = id;
                cachedRotation = rotation;
            }
            out.set(cachedBounds);
        } else {
            view.getWindowVisibleDisplayFrame(out);
        }
    }

    static void invalidate() {
        cachedBounds.setEmpty();
    }

    static void fitOverlay(WindowManager.LayoutParams placement) {
        if (Build.VERSION.SDK_INT >= 30) {
            placement.setFitInsetsTypes(reservedTypes());
            placement.setFitInsetsIgnoringVisibility(true);
        }
    }

    private static int reservedTypes() {
        return WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout();
    }
}
