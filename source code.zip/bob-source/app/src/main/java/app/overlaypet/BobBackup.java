package app.overlaypet;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Only Bob's game state is portable. Each file is validated before editing preferences. */
final class BobBackup {
    private static final String APPEARANCE = "appearance";
    private static final String FOOD = "food_choices";

    static String readText(InputStream in, int limit) throws IOException {
        if (in == null) throw new IOException("Cannot open file");
        try (InputStream input = in; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] block = new byte[4096];
            int count;
            while ((count = input.read(block)) != -1) {
                if (bytes.size() + count > limit) throw new IOException("File too large");
                bytes.write(block, 0, count);
            }
            return new String(bytes.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    static JSONObject snapshot(Context context) throws JSONException {
        JSONObject data = new JSONObject().put("format", "bob-save").put("schema", 1);
        for (String group : new String[]{APPEARANCE, FOOD}) {
            JSONObject values = new JSONObject();
            for (Map.Entry<String, ?> entry : context.getSharedPreferences(group, 0).getAll().entrySet()) {
                Object value = entry.getValue();
                values.put(entry.getKey(), value instanceof Set ? new JSONArray((Set<?>) value) : value);
            }
            data.put(group, values);
        }
        return data;
    }

    static void restore(Context context, JSONObject data) throws Exception {
        if (!"bob-save".equals(data.getString("format")) || data.getInt("schema") != 1)
            throw new JSONException("Unrecognized Bob save");
        JSONObject previous = snapshot(context);
        SharedPreferences.Editor appearance = editor(context, APPEARANCE, data);
        SharedPreferences.Editor food = editor(context, FOOD, data);
        if (!appearance.commit() || !food.commit()) {
            editor(context, APPEARANCE, previous).commit();
            editor(context, FOOD, previous).commit();
            throw new IOException("Storage unavailable");
        }
    }

    private static SharedPreferences.Editor editor(Context context, String group, JSONObject save) throws JSONException {
        JSONObject values = save.getJSONObject(group);
        SharedPreferences.Editor edit = context.getSharedPreferences(group, 0).edit().clear();
        for (Iterator<String> keys = values.keys(); keys.hasNext();) {
            String key = keys.next();
            Object value = values.get(key);
            if (group.equals(FOOD)) {
                if (key.matches("slot_[0-3]")) edit.putString(key, (String) value);
            } else if (key.equals("accessory_combo") || key.equals("unlocked_accessories")) {
                JSONArray array = values.getJSONArray(key);
                Set<String> set = new HashSet<>();
                for (int i = 0; i < array.length(); i++) set.add((String) array.get(i));
                edit.putStringSet(key, set);
            } else if (key.equals("accessory") || key.equals("food_reminder_mode") || key.equals("food_reminder_hours")) {
                edit.putString(key, (String) value);
            } else if (key.equals("accessory_drops_enabled") || key.equals("tap_vibration") ||
                    key.equals("progression_enabled") || key.equals("food_reminders_enabled")) {
                edit.putBoolean(key, (Boolean) value);
            } else if (key.startsWith("progression_last_")) {
                edit.putLong(key, values.getLong(key));
            } else if (key.startsWith("quest_") || key.startsWith("progression_") ||
                    key.equals("food_reminder_min_interval") || key.equals("food_reminder_max_interval")) {
                int n = values.getInt(key);
                if (n < 0 || (key.startsWith("quest_variant_") && n >= 250))
                    throw new JSONException("Invalid progress");
                edit.putInt(key, n);
            }
        }
        return edit;
    }
    private BobBackup() {}
}
