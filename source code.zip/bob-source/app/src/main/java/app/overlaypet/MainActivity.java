package app.overlaypet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.app.TimePickerDialog;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import java.util.EnumSet;
import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int OVERLAY_SETTINGS = 1;
    private ReleaseMenu releases;
    private TextView progressSummary;
    private android.widget.ProgressBar mainProgressBar;
    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshProgress = new Runnable() {
        @Override public void run() {
            updateProgressSummary();
            progressHandler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        releases = new ReleaseMenu(this, state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        layout.setPadding(0, 0, 0, 0);
        layout.setBackgroundColor(Color.rgb(240, 238, 252));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.RIGHT | Gravity.TOP);
        Button help = new Button(this);
        help.setText("?");
        help.setTextSize(19);
        help.setAllCaps(false);
        help.setContentDescription("Questions and answers");
        help.setOnClickListener(view -> showAppHelp());
        topBar.addView(help, dp(48), dp(48));
        layout.addView(topBar, LinearLayout.LayoutParams.MATCH_PARENT, dp(48));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(dp(32), 0, dp(32), dp(32));
        layout.addView(content, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.pet);
        content.addView(icon, dp(88), dp(88));

        TextView title = new TextView(this);
        title.setText("bob");
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(32, 35, 52));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(16));
        content.addView(title);

        progressSummary = new TextView(this);
        progressSummary.setTextSize(13);
        progressSummary.setTextColor(Color.rgb(72, 63, 105));
        progressSummary.setGravity(Gravity.CENTER);
        content.addView(progressSummary, LinearLayout.LayoutParams.MATCH_PARENT, dp(24));
        mainProgressBar = new android.widget.ProgressBar(this, null,
                android.R.attr.progressBarStyleHorizontal);
        content.addView(mainProgressBar, new LinearLayout.LayoutParams(
                dp(220), dp(8)));
        updateProgressSummary();

        Button start = new Button(this);
        start.setText("Start");
        start.setOnClickListener(view -> {
            if (Settings.canDrawOverlays(this)) {
                showPet();
            } else {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())), OVERLAY_SETTINGS);
            }
        });
        content.addView(start, dp(192), dp(54));

        Button stop = new Button(this);
        stop.setText("Stop");
        stop.setOnClickListener(view -> stopService(new Intent(this, PetService.class)));
        content.addView(stop, dp(192), dp(54));

        Button food = new Button(this);
        food.setText("🍔");
        food.setTextSize(22);
        food.setContentDescription("Choose snacks");
        food.setOnClickListener(view -> showFoodChoices());
        LinearLayout menus = new LinearLayout(this);
        Button reminders = new Button(this);
        reminders.setText("🕒🍎");
        reminders.setContentDescription("Food reminder schedule");
        reminders.setOnClickListener(view -> showFoodReminderSettings());
        menus.addView(reminders, dp(78), dp(54));
        menus.addView(food, dp(64), dp(54));

        Button accessories = new Button(this);
        accessories.setText("🎩");
        accessories.setTextSize(22);
        accessories.setContentDescription("Accessories");
        accessories.setOnClickListener(view -> showAccessories());
        menus.addView(accessories, dp(64), dp(54));

        Button levels = new Button(this);
        levels.setText("⭐");
        levels.setTextSize(22);
        levels.setContentDescription("Bob's level and daily tasks");
        levels.setOnClickListener(view -> showProgress());
        menus.addView(levels, dp(64), dp(54));

        Button settings = new Button(this);
        settings.setText("⚙️");
        settings.setTextSize(22);
        settings.setContentDescription("Settings");
        settings.setOnClickListener(view -> showSettings());
        menus.addView(settings, dp(64), dp(54));
        content.addView(menus);

        setContentView(layout);
        releases.checkOnLaunch();
    }

    @Override protected void onResume() {
        super.onResume();
        updateProgressSummary();
        progressHandler.removeCallbacks(refreshProgress);
        progressHandler.postDelayed(refreshProgress, 5000);
    }

    @Override protected void onPause() {
        progressHandler.removeCallbacks(refreshProgress);
        super.onPause();
    }

    private void updateProgressSummary() {
        if (progressSummary == null || mainProgressBar == null) return;
        Progression progress = new Progression(this);
        boolean enabled = Accessory.preferences(this).getBoolean(Progression.ENABLED, false);
        progressSummary.setVisibility(enabled ? View.VISIBLE : View.GONE);
        mainProgressBar.setVisibility(enabled ? View.VISIBLE : View.GONE);
        if (enabled) {
            progressSummary.setText("Level " + progress.level() + " · " + progress.title()
                    + " · " + progress.intoLevel() + "/100 XP");
            mainProgressBar.setMax(100);
            mainProgressBar.setProgress(progress.intoLevel());
        }
    }

    private void showFoodReminderSettings() {
        SharedPreferences prefs = Accessory.preferences(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setPadding(dp(16), dp(8), dp(16), 0);
        panel.setOrientation(LinearLayout.VERTICAL);
        android.widget.Switch enabled = new android.widget.Switch(this);
        enabled.setText("Bob asks for snacks");
        enabled.setChecked(prefs.getBoolean(PetService.REMINDERS_ENABLED, false));
        panel.addView(enabled);
        RadioGroup modes = new RadioGroup(this);
        RadioButton interval = new RadioButton(this);
        interval.setText("Random interval");
        interval.setId(1);
        RadioButton scheduled = new RadioButton(this);
        scheduled.setText("Set hours");
        scheduled.setId(2);
        modes.addView(interval);
        modes.addView(scheduled);
        modes.check(prefs.getString(PetService.REMINDER_MODE, "interval").equals("time") ? 2 : 1);
        panel.addView(modes);

        LinearLayout intervalPanel = new LinearLayout(this);
        intervalPanel.addView(new TextView(this) {{ setText("Random chance every"); setGravity(Gravity.CENTER_VERTICAL); }});
        NumberPicker minMinutes = new NumberPicker(this);
        minMinutes.setMinValue(5); minMinutes.setMaxValue(180);
        minMinutes.setValue(prefs.getInt(PetService.REMINDER_MIN_INTERVAL, 30));
        NumberPicker maxMinutes = new NumberPicker(this);
        maxMinutes.setMinValue(5); maxMinutes.setMaxValue(180);
        maxMinutes.setValue(prefs.getInt(PetService.REMINDER_MAX_INTERVAL, 50));
        intervalPanel.addView(minMinutes, dp(64), dp(80));
        intervalPanel.addView(new TextView(this) {{ setText("to"); setGravity(Gravity.CENTER); }});
        intervalPanel.addView(maxMinutes, dp(64), dp(80));
        intervalPanel.addView(new TextView(this) {{ setText("minutes"); setGravity(Gravity.CENTER_VERTICAL); }});
        panel.addView(intervalPanel);

        LinearLayout hoursPanel = new LinearLayout(this);
        hoursPanel.setOrientation(LinearLayout.VERTICAL);
        hoursPanel.setPadding(dp(12), dp(8), dp(12), dp(8));
        hoursPanel.setBackgroundColor(Color.rgb(246, 244, 255));
        TextView hoursTitle = new TextView(this);
        hoursTitle.setText("At these times");
        hoursTitle.setTextSize(17);
        hoursTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hoursTitle.setTextColor(Color.rgb(48, 43, 76));
        hoursPanel.addView(hoursTitle);
        TextView hoursHint = new TextView(this);
        hoursHint.setText("Bob will ask for a snack once each day at every time below.");
        hoursHint.setTextSize(13);
        hoursHint.setTextColor(Color.rgb(91, 88, 105));
        hoursHint.setPadding(0, dp(3), 0, dp(8));
        hoursPanel.addView(hoursHint);
        List<Integer> times = new ArrayList<>();
        String stored = prefs.getString(PetService.REMINDER_HOURS, "08:00,00:00,18:00");
        for (String value : stored.split(",")) {
            try { String[] parts = value.split(":"); times.add(Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1])); }
            catch (RuntimeException ignored) {}
        }
        LinearLayout rows = new LinearLayout(this);
        Runnable[] rebuildHolder = new Runnable[1];
        Runnable rebuild = rebuildHolder[0] = () -> {
            rows.removeAllViews();
            for (int i = 0; i < times.size(); i++) {
                final int index = i;
                TextView time = new TextView(this);
                int value = times.get(i);
                time.setText(formatReminderTime(value));
                time.setTextSize(16);
                time.setTextColor(Color.rgb(38, 39, 54));
                time.setGravity(Gravity.CENTER_VERTICAL);
                time.setPadding(dp(14), 0, dp(12), 0);
                time.setBackgroundColor(Color.WHITE);
                time.setContentDescription("Reminder time " + formatReminderTime(value) + ". Tap to change.");
                time.setOnClickListener(v -> new TimePickerDialog(this, (picker, h, m) -> {
                    times.set(index, h * 60 + m);
                    rebuildHolder[0].run();
                }, value / 60, value % 60, false).show());
                Button minus = new Button(this);
                minus.setText("Remove");
                minus.setTextSize(12);
                minus.setContentDescription("Remove " + formatReminderTime(value));
                minus.setOnClickListener(v -> { times.remove(index); rebuildHolder[0].run(); });
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(2), 0, dp(2));
                row.addView(time, new LinearLayout.LayoutParams(0, dp(48), 1));
                row.addView(minus, new LinearLayout.LayoutParams(dp(76), dp(48)));
                rows.addView(row);
            }
        };
        rebuildHolder[0].run();
        hoursPanel.addView(rows);
        Button plus = new Button(this);
        plus.setText("+  Add a time");
        plus.setAllCaps(false);
        plus.setContentDescription("Add a daily reminder time");
        plus.setOnClickListener(v -> {
            java.util.Calendar now = java.util.Calendar.getInstance();
            now.add(java.util.Calendar.HOUR_OF_DAY, 1);
            now.set(java.util.Calendar.MINUTE, 0);
            times.add(now.get(java.util.Calendar.HOUR_OF_DAY) * 60);
            rebuildHolder[0].run();
        });
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        addParams.topMargin = dp(6);
        hoursPanel.addView(plus, addParams);
        panel.addView(hoursPanel);

        Runnable updateMode = () -> {
            intervalPanel.setVisibility(modes.getCheckedRadioButtonId() == 1 ? View.VISIBLE : View.GONE);
            hoursPanel.setVisibility(modes.getCheckedRadioButtonId() == 2 ? View.VISIBLE : View.GONE);
        };
        modes.setOnCheckedChangeListener((group, id) -> updateMode.run());
        updateMode.run();

        new AlertDialog.Builder(this).setTitle("🕒🍎 Food reminders").setView(panel)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    StringBuilder encoded = new StringBuilder();
                    java.util.Collections.sort(times);
                    for (int value : times) {
                        if (encoded.length() > 0) encoded.append(',');
                        encoded.append(String.format(java.util.Locale.US, "%02d:%02d", value / 60, value % 60));
                    }
                    int min = minMinutes.getValue(), max = maxMinutes.getValue();
                    if (min > max) { int swap = min; min = max; max = swap; }
                    prefs.edit().putBoolean(PetService.REMINDERS_ENABLED, enabled.isChecked())
                            .putString(PetService.REMINDER_MODE, modes.getCheckedRadioButtonId() == 2 ? "time" : "interval")
                            .putInt(PetService.REMINDER_MIN_INTERVAL, min)
                            .putInt(PetService.REMINDER_MAX_INTERVAL, max)
                            .putString(PetService.REMINDER_HOURS, encoded.toString()).apply();
                    if (Settings.canDrawOverlays(this)) startForegroundService(new Intent(this, PetService.class));
                }).show();
    }

    private static String formatReminderTime(int minutes) {
        int hour = (minutes / 60) % 24;
        int minute = minutes % 60;
        int displayHour = hour % 12;
        if (displayHour == 0) displayHour = 12;
        return String.format(java.util.Locale.getDefault(), "%d:%02d %s",
                displayHour, minute, hour < 12 ? "AM" : "PM");
    }

    private void showSettings() {
        SharedPreferences preferences = Accessory.preferences(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(8), dp(20), dp(8));
        android.widget.Switch drops = new android.widget.Switch(this);
        drops.setText("Headwear can fall off");
        drops.setChecked(preferences.getBoolean(HatRescue.DROPS_ENABLED, true));
        content.addView(drops);
        android.widget.Switch vibration = new android.widget.Switch(this);
        vibration.setText("Vibrate when Bob is tapped");
        vibration.setChecked(preferences.getBoolean(PetService.TAP_VIBRATION, true));
        content.addView(vibration);
        android.widget.Switch leveling = new android.widget.Switch(this);
        leveling.setText("Enable leveling system");
        leveling.setChecked(preferences.getBoolean(Progression.ENABLED, false));
        content.addView(leveling);
        TextView levelingInfo = new TextView(this);
        levelingInfo.setText("Optional: earn XP by feeding, playing, completing Bob's snack requests, and catching thrown headwear. XP is capped at 60 per day. Existing accessories stay available; new hats and accessories unlock as you level up.");
        levelingInfo.setTextSize(13);
        levelingInfo.setTextColor(Color.rgb(88, 86, 102));
        content.addView(levelingInfo);
        Button changelog = new Button(this);
        changelog.setText("Changelog");
        changelog.setOnClickListener(v -> releases.showChangelog());
        content.addView(changelog);
        Button versions = new Button(this);
        versions.setText("Change versions");
        versions.setOnClickListener(v -> releases.showVersions());
        content.addView(versions);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Settings").setView(scroll)
                .setNeutralButton("Calibrate screen", (dialog, button) -> calibrateScreen())
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, button) -> {
                    preferences.edit().putBoolean(HatRescue.DROPS_ENABLED, drops.isChecked())
                            .putBoolean(PetService.TAP_VIBRATION, vibration.isChecked())
                            .putBoolean(Progression.ENABLED, leveling.isChecked()).apply();
                    if (leveling.isChecked()) new Progression(this).unlockRewards();
                    updateProgressSummary();
                }).show();
    }

    private void showProgress() {
        Progression progress = new Progression(this);
        if (!Accessory.preferences(this).getBoolean(Progression.ENABLED, false)) {
            new AlertDialog.Builder(this).setTitle("Bob's levels")
                    .setMessage("Turn on “Enable leveling system” in Settings to earn XP, unlock accessories, and complete daily tasks. Missed tasks never remove XP.")
                    .setPositiveButton("Got it", null).show();
            return;
        }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(8), dp(20), dp(8));
        TextView level = new TextView(this);
        level.setText("Level " + progress.level() + " · " + progress.title());
        level.setTextSize(20);
        level.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        level.setTextColor(Color.rgb(48, 43, 76));
        content.addView(level);
        TextView xp = new TextView(this);
        xp.setText(progress.intoLevel() + " / 100 XP to next level · " + progress.remainingToday() + " XP left today");
        xp.setTextSize(13);
        content.addView(xp);
        android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null,
                android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setProgress(progress.intoLevel());
        content.addView(bar, LinearLayout.LayoutParams.MATCH_PARENT, dp(10));
        TextView tasksHeader = new TextView(this);
        tasksHeader.setText("Today's quests · 4 picked from 1,000");
        tasksHeader.setTextSize(16);
        tasksHeader.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tasksHeader.setPadding(0, dp(12), 0, dp(4));
        content.addView(tasksHeader);
        for (int i = 0; i < 4; i++) {
            TextView task = new TextView(this);
            String detail = i == 2 ? " (bounce each throw, then catch)"
                    : i == 3 ? " (two in a row; Bob in upper area)" : "";
            task.setText((progress.taskDone(i) ? "✓ " : "○ ") + progress.taskName(i) + detail
                    + (progress.taskDone(i) ? " · Done" : " · " + progress.taskProgress(i) + "/"
                    + progress.taskTarget(i) + " · +" + progress.taskReward(i) + " XP"));
            task.setTextSize(14);
            task.setPadding(dp(8), dp(7), dp(8), dp(7));
            if (i == 3) {
                android.graphics.drawable.GradientDrawable zone = new android.graphics.drawable.GradientDrawable();
                zone.setColor(Color.rgb(238, 231, 255));
                zone.setCornerRadius(dp(10));
                zone.setStroke(dp(1), Color.rgb(147, 112, 219));
                task.setBackground(zone);
                task.setTextColor(Color.rgb(67, 44, 112));
            }
            content.addView(task);
        }
        content.addView(new TextView(this) {{ setText("The quest set refreshes at local midnight. Titles: Tiny Pal (1), Snack Buddy (5), Best Bud (10), Bob Legend (20). Level unlocks: Star Hat (3), Witch Hat (5), Rainbow Hat (8), Cloud Cap (12), Golden Topper (20), Scarf (21), Halo (22), Wings (23), Backpack (24), Heart Pin (25)."); setTextSize(12); setTextColor(Color.rgb(88,86,102)); setPadding(0,dp(8),0,0); }});
        new AlertDialog.Builder(this).setTitle("Bob's progress").setView(content)
                .setPositiveButton("Done", null).show();
    }

    private void showAppHelp() {
        String help = "How do I start or stop Bob?\nUse the Start and Stop buttons on the main screen. Android will ask for overlay permission the first time.\n\nHow do I feed Bob?\nChoose a snack with the 🍔 button, then drag the snack to Bob while he is awake.\n\nHow do snack reminders work?\nOpen 🕒🍎 to turn reminders on and choose a random interval or daily times. Bob asks for one of your selected snacks.\n\nWhat counts as a trickshot?\nThrow a detached hat or crown and catch it on Bob after it hits a screen edge or the floor. Only bounces after you throw count. A missed throw or one with no bounce breaks the streak.\n\nWhat is the Mega Quest?\nThe fourth quest needs two successful trickshots in a row while Bob is in the upper quarter of the usable screen. Each throw must bounce once and land on Bob; a missed throw resets the streak.\n\nHow many quests are there?\nBob has 1,000 quest variations. Four are picked each day and refresh at local midnight. Multi-trickshot quests require consecutive successful trickshots.\n\nHow does leveling work?\nTurn on Enable leveling system in Settings. Earn XP from feeding, playing, snack requests, and trickshots. XP has cooldowns and a 60-point daily cap. Missed quests never remove XP. Existing accessories stay available; new hats and accessories unlock from levels 3 to 25.\n\nCan I change accessories?\nUse 🎩 to select accessories. You can combine them; only one loose hat can be worn at a time.\n\nWhat are the level titles?\nTiny Pal (level 1), Snack Buddy (5), Best Bud (10), and Bob Legend (20).";
        new AlertDialog.Builder(this).setTitle("Help & Q&A").setMessage(help)
                .setPositiveButton("Done", null).show();
    }

    private void calibrateScreen() {
        PlayArea.invalidate();
        Rect area = new Rect();
        PlayArea.measure(getWindow().getDecorView(), area);
        new AlertDialog.Builder(this)
                .setTitle("Screen calibrated")
                .setMessage(area.width() + " × " + area.height()
                        + " px of usable space. System bars and screen cutouts are reserved.")
                .setPositiveButton("Done", null)
                .show();
    }

    private void showAccessories() {
        EnumSet<Accessory> available = EnumSet.complementOf(EnumSet.of(Accessory.NONE));
        Accessory[] choices = available.toArray(new Accessory[0]);
        EnumSet<Accessory> selected = Accessory.selected(this);
        String[] labels = new String[choices.length];
        boolean[] checked = new boolean[choices.length];
        for (int index = 0; index < choices.length; index++) {
            boolean unlocked = Accessory.unlocked(this, choices[index]);
            if (choices[index].unlockLevel >= 21) {
                labels[index] = choices[index].label + "  ·  Level " + choices[index].unlockLevel
                        + (unlocked ? "" : " 🔒");
            } else {
                labels[index] = unlocked ? choices[index].label
                        : choices[index].label + "  🔒 Level " + choices[index].unlockLevel;
            }
            checked[index] = selected.contains(choices[index]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Accessories")
                .setMultiChoiceItems(labels, checked, (dialog, choice, enabled) -> {
                    Accessory accessory = choices[choice];
                    if (enabled && !Accessory.unlocked(this, accessory)) {
                        ((AlertDialog) dialog).getListView().setItemChecked(choice, false);
                        android.widget.Toast.makeText(this, "Unlock at level " + accessory.unlockLevel,
                                android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (enabled) {
                        if (accessory.canFallOff()) {
                            Accessory previous = Accessory.headwear(selected);
                            if (previous != Accessory.NONE && previous != accessory) {
                                selected.remove(previous);
                                for (int index = 0; index < choices.length; index++) {
                                    if (choices[index] == previous) {
                                        checked[index] = false;
                                        ((AlertDialog) dialog).getListView().setItemChecked(index, false);
                                        break;
                                    }
                                }
                            }
                        }
                        selected.add(accessory);
                    } else {
                        selected.remove(accessory);
                    }
                    Accessory.save(this, selected);
                })
                .setPositiveButton("Done", null)
                .show();
    }

    private void showFoodChoices() {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(20), dp(8), dp(20), dp(8));
        ArrayAdapter<FoodChoices.Food> options = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, FoodChoices.OPTIONS);
        options.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner[] dropdowns = new Spinner[FoodChoices.SLOT_COUNT];
        for (int slot = 0; slot < dropdowns.length; slot++) {
            Spinner dropdown = new Spinner(this, Spinner.MODE_DROPDOWN);
            dropdown.setContentDescription("Snack " + (slot + 1));
            dropdown.setAdapter(options);
            dropdown.setSelection(FoodChoices.selectedIndex(this, slot));
            fields.addView(dropdown, LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
            dropdowns[slot] = dropdown;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Choose snacks")
                .setView(fields)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Reset", null)
                .setPositiveButton("Save", (window, button) -> {
                    int[] selections = new int[dropdowns.length];
                    for (int slot = 0; slot < selections.length; slot++) {
                        selections[slot] = dropdowns[slot].getSelectedItemPosition();
                    }
                    FoodChoices.save(this, selections);
                })
                .show();
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view -> {
            for (int slot = 0; slot < dropdowns.length; slot++) {
                dropdowns[slot].setSelection(FoodChoices.defaultIndex(slot));
            }
        });
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (releases.onDocumentResult(request, result, data)) return;
        if (request == OVERLAY_SETTINGS && Settings.canDrawOverlays(this)) showPet();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && releases != null) releases.maybePrompt();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        releases.saveState(state);
    }

    @Override protected void onDestroy() {
        releases.close();
        super.onDestroy();
    }

    private void showPet() {
        startForegroundService(new Intent(this, PetService.class));
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
