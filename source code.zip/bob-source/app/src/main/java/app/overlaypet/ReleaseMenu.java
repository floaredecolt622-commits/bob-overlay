package app.overlaypet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.HashSet;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Release files are fetched only from Bob's public repository. */
final class ReleaseMenu {
    private static final String REPO = "floaredecolt622-commits/bob-overlay";
    private static final String RAW = "https://raw.githubusercontent.com/" + REPO + "/main/";
    private static final String ARCHIVE = "https://github.com/" + REPO + "/tree/main/versions";
    private static final int BACKUP = 501, RESTORE = 502, APK = 503;
    private final MainActivity activity;
    private final SharedPreferences prefs;
    private final int installedCode;
    private final String installedName;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Release> catalog = new ArrayList<>();
    private boolean checking;
    private boolean automaticPrompt;
    private AlertDialog picker;
    private LinearLayout choices;
    private String status = "";
    private Release pending;
    private boolean backingUpForSwitch;

    private static final class Release {
        final JSONObject json;
        final int code;
        final String name, path, digest, notes;

        Release(JSONObject json) throws Exception {
            this.json = json;
            code = json.getInt("versionCode");
            name = json.getString("versionName");
            path = json.getString("apk");
            digest = json.getString("sha256");
            notes = json.getString("notes");
            if (code < 68 || !name.matches("[0-9]+([.][0-9]+){1,2}") ||
                    !(path.equals("bob-v" + name + ".apk") || path.equals("versions/bob-v" + name + ".apk")) ||
                    !digest.matches("[a-f0-9]{64}")) throw new IOException("Invalid release");
        }
    }

    ReleaseMenu(MainActivity activity, Bundle saved) {
        this.activity = activity;
        prefs = activity.getSharedPreferences("release_catalog", 0);
        try {
            android.content.pm.PackageInfo info = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            installedCode = info.versionCode;
            installedName = info.versionName;
        } catch (android.content.pm.PackageManager.NameNotFoundException missing) {
            throw new IllegalStateException(missing);
        }
        try {
            catalog.addAll(parse(prefs.getString("catalog", "")));
        } catch (Exception ignored) { /* First launch, or an old cache. */ }
        if (saved != null && saved.containsKey("releaseSelection")) {
            try {
                pending = new Release(new JSONObject(saved.getString("releaseSelection")));
                backingUpForSwitch = saved.getBoolean("releaseBackup");
            } catch (Exception ignored) { pending = null; }
        }
    }

    void saveState(Bundle out) {
        if (pending != null) {
            out.putString("releaseSelection", pending.json.toString());
            out.putBoolean("releaseBackup", backingUpForSwitch);
        }
    }

    void close() { io.shutdown(); }
    private boolean alive() { return !activity.isDestroyed() && !activity.isFinishing(); }
    private void onUi(Runnable action) { activity.runOnUiThread(() -> { if (alive()) action.run(); }); }

    private static List<Release> parse(String text) throws Exception {
        JSONObject root = new JSONObject(text);
        if (root.getInt("schema") != 1) throw new IOException("Unknown catalog");
        JSONArray list = root.getJSONArray("releases");
        List<Release> versions = new ArrayList<>();
        HashSet<Integer> codes = new HashSet<>();
        for (int i = 0; i < list.length(); i++) {
            JSONObject entry = list.getJSONObject(i);
            if (!entry.getBoolean("switchable")) continue;
            Release version = new Release(entry);
            if (!codes.add(version.code)) throw new IOException("Duplicate release");
            versions.add(version);
        }
        Collections.sort(versions, (a, b) -> Integer.compare(b.code, a.code));
        return versions;
    }

    private static HttpURLConnection open(String file) throws IOException {
        HttpURLConnection http = (HttpURLConnection)new URL(RAW + file).openConnection();
        http.setConnectTimeout(6500);
        http.setReadTimeout(15000);
        http.setInstanceFollowRedirects(false);
        http.setUseCaches(false);
        try {
            if (http.getResponseCode() != 200) throw new IOException("GitHub unavailable");
            return http;
        } catch (IOException error) {
            http.disconnect();
            throw error;
        }
    }

    void checkOnLaunch() {
        if (pending == null) check(true);
    }

    private void check(boolean automatic) {
        automaticPrompt = automatic;
        if (checking) return;
        checking = true;
        status = "Checking GitHub…";
        refreshPicker();
        io.execute(() -> {
            try {
                HttpURLConnection http = open("updates.json");
                String result;
                try { result = BobBackup.readText(http.getInputStream(), 256 * 1024); }
                finally { http.disconnect(); }
                List<Release> entries = parse(result);
                onUi(() -> {
                    checking = false;
                    catalog.clear();
                    catalog.addAll(entries);
                    prefs.edit().putString("catalog", result).apply();
                    status = entries.isEmpty() ? "No compatible releases are listed." :
                            entries.get(0).code <= installedCode ? "You have the latest release." : "An update is available.";
                    refreshPicker();
                    maybePrompt();
                });
            } catch (Exception error) {
                onUi(() -> {
                    checking = false;
                    status = "Couldn’t reach the release list. Tap Check again to retry.";
                    refreshPicker();
                });
            }
        });
    }

    void maybePrompt() {
        if (checking || !automaticPrompt || catalog.isEmpty() || !activity.hasWindowFocus() || picker != null || pending != null) return;
        Release latest = catalog.get(0);
        if (latest.code <= installedCode || latest.code <= prefs.getInt("skipped", 0)) return;
        automaticPrompt = false;
        new AlertDialog.Builder(activity).setTitle("Hey! A new update is available!")
                .setMessage("Bob v" + latest.name + " is ready.")
                .setNegativeButton("Skip", (d, w) -> prefs.edit().putInt("skipped", latest.code).apply())
                .setPositiveButton("Continue", (d, w) -> details(latest)).show();
    }

    void showVersions() {
        automaticPrompt = false;
        choices = new LinearLayout(activity);
        choices.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(18 * activity.getResources().getDisplayMetrics().density);
        choices.setPadding(pad, pad / 2, pad, pad / 2);
        ScrollView scroll = new ScrollView(activity);
        scroll.addView(choices);
        picker = new AlertDialog.Builder(activity).setTitle("Change versions").setView(scroll)
                .setPositiveButton("Done", null).create();
        picker.setOnDismissListener(d -> { picker = null; choices = null; });
        picker.show();
        refreshPicker();
        check(false);
    }

    private void button(String label, Runnable click) {
        Button item = new Button(activity);
        item.setText(label);
        item.setAllCaps(false);
        item.setOnClickListener(v -> click.run());
        choices.addView(item);
    }

    private void refreshPicker() {
        if (choices == null) return;
        choices.removeAllViews();
        TextView info = new TextView(activity);
        info.setText("Installed · Bob v" + installedName + "\n" + status);
        choices.addView(info);
        for (Release release : catalog) {
            if (release.code != installedCode) button("Bob v" + release.name, () -> details(release));
        }
        if (!checking) button("Check again", () -> check(false));
        button("Back up Bob", () -> { pending = null; backup(false); });
        button("Restore Bob", () -> document(RESTORE, "application/json", null));
        button("Legacy APKs", () -> {
            try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ARCHIVE))); }
            catch (android.content.ActivityNotFoundException error) { message("Open GitHub", ARCHIVE); }
        });
    }

    private void details(Release release) {
        boolean older = release.code < installedCode;
        String text = release.notes + (older ? "\n\nAndroid requires uninstalling Bob to use an older APK. Save a backup and the APK to Downloads first. After installing, use Restore Bob to bring back your progress." : "");
        new AlertDialog.Builder(activity).setTitle("Bob v" + release.name).setMessage(text)
                .setNegativeButton("Cancel", null)
                .setPositiveButton(older ? "Back up and continue" : "Download APK", (d, w) -> {
                    pending = release;
                    if (older) backup(true); else saveApk();
                }).show();
    }

    private void backup(boolean forSwitch) {
        backingUpForSwitch = forSwitch;
        document(BACKUP, "application/json", "bob-save.json");
    }

    private void saveApk() { document(APK, "application/vnd.android.package-archive", "bob-v" + pending.name + ".apk"); }

    private void document(int request, String type, String name) {
        Intent intent = new Intent(name == null ? Intent.ACTION_OPEN_DOCUMENT : Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE).setType(type);
        if (name != null) intent.putExtra(Intent.EXTRA_TITLE, name);
        try { activity.startActivityForResult(intent, request); }
        catch (android.content.ActivityNotFoundException error) {
            pending = null;
            backingUpForSwitch = false;
            message("File picker unavailable", "Enable Android’s Files app to choose a document.");
        }
    }

    boolean onDocumentResult(int request, int result, Intent data) {
        if (request != BACKUP && request != RESTORE && request != APK) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) {
            pending = null;
            backingUpForSwitch = false;
            return true;
        }
        Uri uri = data.getData();
        if (request == RESTORE) {
            new AlertDialog.Builder(activity).setTitle("Restore Bob?")
                    .setMessage("Replace Bob’s current progress, outfit and settings with this save?")
                    .setNegativeButton("Cancel", null).setPositiveButton("Restore", (d,w) -> restore(uri)).show();
        } else if (request == BACKUP) {
            writeBackup(uri);
        } else if (pending != null) {
            Release selected = pending;
            pending = null;
            download(selected, uri);
        }
        return true;
    }

    private void writeBackup(Uri uri) {
        io.execute(() -> {
            try {
                try (OutputStream out = activity.getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new IOException();
                    out.write(BobBackup.snapshot(activity).toString().getBytes(StandardCharsets.UTF_8));
                }
                onUi(() -> {
                    toast("Bob’s backup is saved.");
                    if (backingUpForSwitch && pending != null) {
                        backingUpForSwitch = false;
                        saveApk();
                    }
                });
            } catch (Exception error) {
                onUi(() -> { backingUpForSwitch = false; pending = null;
                    message("Backup failed", "Choose a writable folder and try again."); });
            }
        });
    }

    private void restore(Uri uri) {
        io.execute(() -> {
            try {
                JSONObject save = new JSONObject(BobBackup.readText(activity.getContentResolver().openInputStream(uri), 128 * 1024));
                onUi(() -> {
                    try {
                        BobBackup.restore(activity, save);
                        activity.recreate();
                        toast("Bob’s progress and settings are restored.");
                    } catch (Exception error) { message("Couldn’t restore Bob", "Choose a valid Bob backup."); }
                });
            } catch (Exception error) { onUi(() -> message("Couldn’t read backup", "Choose a Bob save file and try again.")); }
        });
    }

    private void download(Release release, Uri destination) {
        toast("Downloading Bob v" + release.name + "…");
        io.execute(() -> {
            File temporary = null;
            try {
                temporary = File.createTempFile("bob-update-", ".apk", activity.getCacheDir());
                HttpURLConnection http = open(release.path);
                MessageDigest hash = MessageDigest.getInstance("SHA-256");
                try (InputStream in = http.getInputStream(); OutputStream out = new FileOutputStream(temporary)) {
                    byte[] block = new byte[8192];
                    int count;
                    long bytes = 0;
                    while ((count = in.read(block)) != -1) {
                        bytes += count;
                        if (bytes > 64L * 1024 * 1024) throw new IOException("File too large");
                        hash.update(block, 0, count);
                        out.write(block, 0, count);
                    }
                } finally { http.disconnect(); }
                StringBuilder hex = new StringBuilder();
                for (byte b : hash.digest()) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
                if (!release.digest.contentEquals(hex)) throw new IOException("Incorrect APK digest");
                try (InputStream in = new FileInputStream(temporary);
                     OutputStream out = activity.getContentResolver().openOutputStream(destination, "wt")) {
                    if (out == null) throw new IOException();
                    byte[] block = new byte[8192];
                    int count;
                    while ((count = in.read(block)) != -1) out.write(block, 0, count);
                }
                onUi(() -> {
                    if (release.code < installedCode) {
                        message("Bob v" + release.name + " is ready", "Your APK and backup are saved. Uninstall Bob, open the saved APK in Files, then choose Settings → Change versions → Restore Bob.");
                    } else {
                        message("Bob v" + release.name + " is ready",
                                "Open the saved APK in Android’s Files app to install the update.");
                    }
                });
            } catch (Exception error) {
                onUi(() -> message("Download failed", "The APK could not be saved and verified. Choose the version again to retry."));
            } finally { if (temporary != null) temporary.delete(); }
        });
    }

    void showChangelog() {
        try {
            StringBuilder notes = new StringBuilder();
            for (Release release : catalog) {
                if (release.code > installedCode)
                    notes.append("v").append(release.name).append(" · Available update\n")
                            .append(release.notes).append("\n\n");
            }
            notes.append(BobBackup.readText(activity.getAssets().open("changelog.txt"), 128 * 1024));
            message("Changelog", notes.toString());
        }
        catch (IOException error) { message("Changelog", "Release notes are unavailable."); }
    }

    private void toast(String text) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }
    private void message(String title, String text) {
        new AlertDialog.Builder(activity).setTitle(title).setMessage(text).setPositiveButton("Done", null).show();
    }
}
