package app.overlaypet;

import android.animation.ObjectAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.app.TimePickerDialog;
import android.widget.TimePicker;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.VibrationAttributes;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.concurrent.ThreadLocalRandom;
import java.util.EnumSet;
import java.util.Calendar;
import java.util.function.BiConsumer;

public final class PetService extends Service {
    static final String TAP_VIBRATION = "tap_vibration";
    static final String REMINDERS_ENABLED = "food_reminders_enabled";
    static final String REMINDER_MODE = "food_reminder_mode";
    static final String REMINDER_MIN_INTERVAL = "food_reminder_min_interval";
    static final String REMINDER_MAX_INTERVAL = "food_reminder_max_interval";
    static final String REMINDER_HOURS = "food_reminder_hours";
    private static final double SHAKE_RATE = 0.07;
    private static final VibrationEffect SHAKE_VIBRATION = createShakeVibration();
    static final float EDGE_BOUNCE = 0.65f;
    static final float SLIDE_FRICTION = 2.8f;
    private static final OvershootInterpolator BUBBLE_POP = new OvershootInterpolator(1.25f);
    private static final String CHANNEL = "overlay_pet";
    private static final String[] DIZZY_LINES = {
        "WHOAAAAA!", "Wheee!", "So spinny!", "Which way?", "Wobble!", "My head!", "Loop de loop!"
    };
    private static final String[] REACTIONS = {
        "Euch!", "Owch!", "Ow", "Eep!", "Ack!", "Hey!", "Whoa!"
    };
    private WindowManager windows;
    private Vibrator vibrator;
    private PetView pet;
    private FoodView food;
    private LinearLayout snackPicker;
    private TextView sleepMessage;
    private EnumSet<Accessory> accessories;
    private HatRescue hatRescue;
    private long reminderDueAt;
    private long lastReminderWallTime;
    private int reminderIndex;
    private boolean reminderRequestActive;
    private Progression progression;
    private String reminderFood;
    private String requestedFood;
    private long reminderStartedAt;
    private long reminderRequestExpiresAt;
    private long nextReminderBlinkAt;
    private final Runnable reminderCheck = this::checkFoodReminder;
    private final SharedPreferences.OnSharedPreferenceChangeListener accessoryChanged =
            (preferences, key) -> {
                if (TAP_VIBRATION.equals(key) && !preferences.getBoolean(TAP_VIBRATION, true)) {
                    cancelTapVibration();
                }
                if (HatRescue.DROPS_ENABLED.equals(key)
                        && !preferences.getBoolean(HatRescue.DROPS_ENABLED, true)) {
                    clearHatRescue();
                }
                if (key != null && key.startsWith("food_reminder_")) {
                    cancelFoodReminder();
                    scheduleFoodReminder();
                }
                EnumSet<Accessory> selected = Accessory.selected(this);
                if (!selected.equals(accessories)) {
                    if (Accessory.headwear(selected) != Accessory.headwear(accessories)) {
                        clearHatRescue();
                    }
                    accessories = selected;
                    if (pet != null) pet.invalidate();
                }
            };
    private final Runnable hideSleepMessage = this::dismissSleepMessage;

    @Override public IBinder onBind(Intent intent) {
        return null;
    }

    @Override public void onCreate() {
        super.onCreate();
        progression = new Progression(this);
        vibrator = getSystemService(Vibrator.class);
        accessories = Accessory.selected(this);
        SharedPreferences preferences = Accessory.preferences(this);
        preferences.registerOnSharedPreferenceChangeListener(accessoryChanged);
        scheduleFoodReminder();
    }

    private void cancelFoodReminder() {
        if (pet != null) pet.removeCallbacks(reminderCheck);
    }

    private void scheduleFoodReminder() {
        if (pet == null) return;
        cancelFoodReminder();
        SharedPreferences p = Accessory.preferences(this);
        if (!p.getBoolean(REMINDERS_ENABLED, false)) return;
        long delay;
        if (p.getString(REMINDER_MODE, "interval").equals("time")) {
            Calendar now = Calendar.getInstance();
            long soonest = Long.MAX_VALUE;
            String[] values = p.getString(REMINDER_HOURS, "08:00,00:00,18:00").split(",");
            for (String value : values) {
                try {
                    String[] parts = value.split(":");
                    Calendar next = (Calendar) now.clone();
                    next.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
                    next.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
                    next.set(Calendar.SECOND, 0);
                    next.set(Calendar.MILLISECOND, 0);
                    if (next.getTimeInMillis() <= now.getTimeInMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
                    soonest = Math.min(soonest, next.getTimeInMillis() - now.getTimeInMillis());
                } catch (RuntimeException ignored) {}
            }
            delay = soonest == Long.MAX_VALUE ? 60_000L : soonest;
        } else {
            int min = Math.max(1, p.getInt(REMINDER_MIN_INTERVAL, 30));
            int max = Math.max(min, p.getInt(REMINDER_MAX_INTERVAL, 50));
            delay = ThreadLocalRandom.current().nextLong(min, (long) max + 1) * 60_000L;
        }
        pet.postDelayed(reminderCheck, Math.max(1000, delay));
    }

    private void checkFoodReminder() {
        if (pet == null) return;
        SharedPreferences p = Accessory.preferences(this);
        if (!p.getBoolean(REMINDERS_ENABLED, false)) return;
        FoodChoices.Food choice = FoodChoices.OPTIONS[
                FoodChoices.selectedIndex(this, reminderIndex++ % FoodChoices.SLOT_COUNT)];
        reminderFood = choice.emoji;
        requestedFood = choice.emoji;
        reminderRequestActive = true;
        reminderStartedAt = SystemClock.uptimeMillis();
        reminderRequestExpiresAt = reminderStartedAt + 5 * 60_000L;
        nextReminderBlinkAt = reminderStartedAt;
        pet.invalidate();
        scheduleFoodReminder();
    }

    private boolean showingFoodReminder(long now) {
        return reminderFood != null && now - reminderStartedAt < 120_000;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(
                CHANNEL, "bob", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        startForeground(1, new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.pet)
                .setContentTitle("bob")
                .setContentText("Tap to open controls.")
                .setContentIntent(open)
                .setOngoing(true)
                .build());

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (pet == null) {
            windows = getSystemService(WindowManager.class);
            WindowManager.LayoutParams placement = new WindowManager.LayoutParams(
                    dp(86), dp(96), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            PlayArea.fitOverlay(placement);
            placement.gravity = Gravity.BOTTOM | Gravity.RIGHT;
            placement.x = dp(12);
            placement.y = dp(66);
            PetView view = new PetView(placement);
            try {
                windows.addView(view, placement);
                pet = view;
                scheduleFoodReminder();
            } catch (SecurityException | WindowManager.BadTokenException error) {
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        cancelTapVibration();
        cancelFoodReminder();
        Accessory.preferences(this).unregisterOnSharedPreferenceChangeListener(accessoryChanged);
        clearHatRescue();
        dismissSleepMessage();
        closeSnackPicker();
        if (food != null) removeFood();
        if (pet != null) windows.removeView(pet);
        super.onDestroy();
    }

    @Override public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        PlayArea.invalidate();
        if (pet != null) pet.post(pet::fitOnScreen);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static VibrationEffect createShakeVibration() {
        int[] strengths = {184, 166, 150, 134, 117, 102, 88, 74};
        long[] timing = new long[strengths.length * 2];
        int[] amplitudes = new int[timing.length];
        long previousEnd = 0;
        for (int pulse = 0; pulse < strengths.length; pulse++) {
            // Center each pulse on a left or right peak of the visible shake.
            long duration = 20 - pulse;
            long peak = Math.round((pulse + 0.5) * Math.PI / SHAKE_RATE);
            long start = peak - duration / 2;
            timing[2 * pulse] = start - previousEnd;
            timing[2 * pulse + 1] = duration;
            amplitudes[2 * pulse + 1] = strengths[pulse];
            previousEnd = start + duration;
        }
        return VibrationEffect.createWaveform(timing, amplitudes, -1);
    }

    private void vibrateWithShake() {
        if (vibrator == null || !vibrator.hasVibrator()
                || !Accessory.preferences(this).getBoolean(TAP_VIBRATION, true)
                || Settings.System.getInt(getContentResolver(), Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 0) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 33) {
            vibrator.vibrate(SHAKE_VIBRATION, new VibrationAttributes.Builder()
                    .setUsage(VibrationAttributes.USAGE_TOUCH).build());
        } else {
            vibrator.vibrate(SHAKE_VIBRATION, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build());
        }
    }

    private void cancelTapVibration() {
        if (vibrator != null) vibrator.cancel();
    }

    private void tryDropHat() {
        Accessory accessory = Accessory.headwear(accessories);
        if (hatRescue != null || !accessory.canFallOff()
                || !Accessory.preferences(this).getBoolean(HatRescue.DROPS_ENABLED, true)
                || ThreadLocalRandom.current().nextFloat() >= 0.50f) return;
        HatRescue rescue = new HatRescue(pet, windows, accessory,
                () -> pet.hatPosition(pet.isSleeping(SystemClock.uptimeMillis())),
                () -> pet.isSleeping(SystemClock.uptimeMillis()),
                this::clearHatRescue,
                walls -> progression.recordTrickshot(walls, pet != null && pet.isInTopQuarter()),
                progression::failTrickshot);
        if (rescue.start(pet.hatPosition(true))) hatRescue = rescue;
    }

    private void clearHatRescue() {
        if (hatRescue == null) return;
        hatRescue.close();
        hatRescue = null;
        if (pet != null) pet.invalidate();
    }

    private void showSnackPicker() {
        if (snackPicker != null) return;
        dismissSleepMessage();
        Rect frame = new Rect();
        PlayArea.measure(pet, frame);
        int width = Math.min(dp(176), frame.width());
        int height = dp(42);
        WindowManager.LayoutParams placement = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        PlayArea.fitOverlay(placement);
        placement.gravity = pet.placement.gravity;
        int centerX = pet.placement.x + pet.placement.width - dp(PetView.CENTER_X);
        int maxY = Math.max(0, frame.height() - height);
        int above = pet.placement.y + pet.placement.height - dp(34);
        int below = pet.placement.y + pet.placement.height - dp(89) - height;
        placement.x = Math.max(0, Math.min(frame.width() - width, centerX - width / 2));
        placement.y = Math.max(0, Math.min(maxY, above <= maxY ? above : below));

        LinearLayout picker = new LinearLayout(this);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(13));
        background.setStroke(dp(1), 0xff292538);
        picker.setBackground(background);
        for (int slot = 0; slot < FoodChoices.SLOT_COUNT; slot++) {
            FoodChoices.Food choice = FoodChoices.OPTIONS[FoodChoices.selectedIndex(this, slot)];
            addSnackChoice(picker, choice.emoji, choice.name);
        }
        picker.setPivotX(width - (centerX - placement.x));
        picker.setPivotY(above <= maxY ? height : 0);
        picker.setAlpha(0);
        picker.setScaleX(0.60f);
        picker.setScaleY(0.40f);
        try {
            windows.addView(picker, placement);
            picker.animate().alpha(1).scaleX(1).scaleY(1).setDuration(300)
                    .setInterpolator(BUBBLE_POP).start();
            snackPicker = picker;
            pet.invalidate();
        } catch (SecurityException | WindowManager.BadTokenException error) {
            stopSelf();
        }
    }

    private void addSnackChoice(LinearLayout picker, String emoji, String name) {
        TextView choice = new TextView(this);
        choice.setText(emoji);
        choice.setTextSize(23);
        choice.setGravity(Gravity.CENTER);
        choice.setContentDescription(name);
        choice.setOnClickListener(view -> {
            closeSnackPicker();
            spawnFood(emoji, name);
        });
        picker.addView(choice, new LinearLayout.LayoutParams(0, -1, 1f));
    }

    private void closeSnackPicker() {
        if (snackPicker == null) return;
        snackPicker.animate().cancel();
        windows.removeView(snackPicker);
        snackPicker = null;
        pet.invalidate();
    }

    private void spawnFood(String emoji, String name) {
        if (food != null) removeFood();
        Rect frame = new Rect();
        PlayArea.measure(pet, frame);
        int size = dp(42);
        WindowManager.LayoutParams placement = new WindowManager.LayoutParams(
                size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        PlayArea.fitOverlay(placement);
        placement.gravity = pet.placement.gravity;
        int centeredX = pet.placement.x + pet.placement.width - dp(PetView.CENTER_X) - size / 2;
        int centeredY = pet.placement.y + pet.placement.height - dp(PetView.CENTER_Y) - size / 2;
        int maxX = Math.max(0, frame.width() - size);
        int maxY = Math.max(0, frame.height() - size);
        // The farthest corner keeps the snack away from bob on very small displays.
        placement.x = centeredX > maxX / 2f ? 0 : maxX;
        placement.y = centeredY > maxY / 2f ? 0 : maxY;
        double minimumDistance = Math.min(dp(160),
                0.8 * Math.hypot(placement.x - centeredX, placement.y - centeredY));
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 32; attempt++) {
            int x = random.nextInt(maxX + 1);
            int y = random.nextInt(maxY + 1);
            if (Math.hypot(x - centeredX, y - centeredY) >= minimumDistance) {
                placement.x = x;
                placement.y = y;
                break;
            }
        }
        FoodView view = new FoodView(placement, emoji, name);
        try {
            windows.addView(view, placement);
            food = view;
            view.popIn();
        } catch (SecurityException | WindowManager.BadTokenException error) {
            stopSelf();
        }
    }

    private void removeFood() {
        FoodView eaten = food;
        food = null;
        windows.removeView(eaten);
    }

    private boolean feedIfTouching(float x, float y, float dx, float dy) {
        // Find the closest point on the relative movement segment to bob's center.
        float lengthSquared = dx * dx + dy * dy;
        float closest = lengthSquared == 0 ? 0
                : Math.max(0, Math.min(1, -(x * dx + y * dy) / lengthSquared));
        if (Math.hypot(x + dx * closest, y + dy * closest) > dp(40)) return false;
        if (pet.isSleeping(SystemClock.uptimeMillis())) {
            showSleepMessage();
            return false;
        }
        boolean matchesRequest = food != null && reminderRequestActive
                && requestedFood != null && requestedFood.equals(food.emoji)
                && SystemClock.uptimeMillis() < reminderRequestExpiresAt;
        removeFood();
        dismissSleepMessage();
        boolean requestCompleted = matchesRequest;
        reminderRequestActive = false;
        progression.award("feed", 10, 30 * 60_000L);
        progression.recordFeed();
        if (requestCompleted) progression.award("request", 10, 20 * 60 * 60_000L);
        pet.startChewing();
        return true;
    }

    private void showSleepMessage() {
        if (sleepMessage != null) return;
        Rect frame = new Rect();
        PlayArea.measure(pet, frame);
        int width = Math.min(dp(228), frame.width());
        int height = dp(56);
        WindowManager.LayoutParams placement = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT);
        PlayArea.fitOverlay(placement);
        placement.gravity = pet.placement.gravity;
        placement.alpha = 0.8f;
        int centerX = pet.placement.x + pet.placement.width - dp(PetView.CENTER_X);
        int maxY = Math.max(0, frame.height() - height);
        int above = pet.placement.y + pet.placement.height - dp(36);
        int below = pet.placement.y + pet.placement.height - dp(89) - height;
        placement.x = Math.max(0, Math.min(frame.width() - width, centerX - width / 2));
        placement.y = Math.max(0, Math.min(maxY, above <= maxY ? above : below));

        TextView message = new TextView(this);
        message.setText("He is sleeping, feed him when he is awake");
        message.setTextSize(14);
        message.setTextColor(0xff292538);
        message.setGravity(Gravity.CENTER);
        message.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(13));
        background.setStroke(dp(1), 0xff292538);
        message.setBackground(background);
        try {
            windows.addView(message, placement);
            sleepMessage = message;
            message.postDelayed(hideSleepMessage, 2800);
        } catch (SecurityException | WindowManager.BadTokenException error) {
            stopSelf();
        }
    }

    private void dismissSleepMessage() {
        if (sleepMessage == null) return;
        sleepMessage.removeCallbacks(hideSleepMessage);
        windows.removeView(sleepMessage);
        sleepMessage = null;
    }

    private final class FoodView extends TextView {
        private static final long SPARKLE_MS = 520;
        private final WindowManager.LayoutParams placement;
        private final String emoji;
        private final SlideMotion slide;
        private final Rect bounds = new Rect();
        private float downX, downY, lastX, lastY, vx, vy;
        private long lastMovement;
        private int originX, originY;
        private boolean holding;
        private boolean dragged;
        private ObjectAnimator wobble;
        private final Paint sparklePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path sparkle = new Path();
        private long spawnedAt = -SPARKLE_MS;

        FoodView(WindowManager.LayoutParams placement, String emoji, String name) {
            super(PetService.this);
            this.placement = placement;
            this.emoji = emoji;
            slide = new SlideMotion(this, placement, this::move);
            setText(emoji);
            setTextSize(27);
            setGravity(Gravity.CENTER);
            setContentDescription(name);
        }

        private void popIn() {
            spawnedAt = SystemClock.uptimeMillis();
            setAlpha(0);
            setScaleX(0.55f);
            setScaleY(0.55f);
            animate().alpha(1).scaleX(1).scaleY(1).setDuration(280)
                    .setInterpolator(new OvershootInterpolator(1.6f)).start();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long elapsed = SystemClock.uptimeMillis() - spawnedAt;
            if (elapsed >= SPARKLE_MS) return;
            float progress = elapsed / (float) SPARKLE_MS;
            float distance = getWidth() * (0.20f + progress * 0.19f);
            float tip = dp(3) * (1 - progress * 0.65f);
            sparklePaint.setColor(0xffffcc55);
            sparklePaint.setAlpha(Math.round(255 * (1 - progress)));
            for (int index = 0; index < 5; index++) {
                double angle = index * 2 * Math.PI / 5 - Math.PI / 2 + progress * 0.4;
                float x = getWidth() / 2f + distance * (float) Math.cos(angle);
                float y = getHeight() / 2f + distance * (float) Math.sin(angle);
                canvas.save();
                canvas.translate(x, y);
                canvas.rotate(index * 17);
                sparkle.rewind();
                sparkle.moveTo(0, -tip);
                sparkle.lineTo(tip * 0.25f, -tip * 0.25f);
                sparkle.lineTo(tip, 0);
                sparkle.lineTo(tip * 0.25f, tip * 0.25f);
                sparkle.lineTo(0, tip);
                sparkle.lineTo(-tip * 0.25f, tip * 0.25f);
                sparkle.lineTo(-tip, 0);
                sparkle.lineTo(-tip * 0.25f, -tip * 0.25f);
                sparkle.close();
                canvas.drawPath(sparkle, sparklePaint);
                canvas.restore();
            }
            postInvalidateOnAnimation();
        }

        private void settle(boolean tap) {
            animate().scaleX(1).scaleY(1).setDuration(360)
                    .setInterpolator(new OvershootInterpolator()).start();
            float tilt = getRotation();
            wobble = ObjectAnimator.ofFloat(this, View.ROTATION, tilt,
                    tap ? -13 : -tilt * 0.55f, tap ? 8 : tilt * 0.25f, 0);
            wobble.setDuration(360);
            wobble.start();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float x = event.getRawX();
            float y = event.getRawY();
            long time = event.getEventTime();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    slide.stop();
                    animate().cancel();
                    if (wobble != null) wobble.cancel();
                    setAlpha(1);
                    holding = true;
                    dragged = false;
                    downX = lastX = x;
                    downY = lastY = y;
                    originX = placement.x;
                    originY = placement.y;
                    vx = vy = 0;
                    lastMovement = time;
                    return true;
                case MotionEvent.ACTION_MOVE:
                case MotionEvent.ACTION_UP:
                    if (food != this || !holding) return true;
                    if (x != lastX || y != lastY) {
                        float seconds = Math.max(8, time - lastMovement) / 1000f;
                        vx = (x - lastX) / seconds;
                        vy = (y - lastY) / seconds;
                        lastX = x;
                        lastY = y;
                        lastMovement = time;
                    }
                    if (!dragged && Math.hypot(x - downX, y - downY) > dp(4)) {
                        dragged = true;
                        animate().scaleX(0.90f).scaleY(1.10f).setDuration(120)
                                .setInterpolator(new OvershootInterpolator()).start();
                    }
                    if (dragged) {
                        float tilt = Math.max(-14, Math.min(14, vx / dp(1) / 65));
                        setRotation(getRotation() + (tilt - getRotation()) * 0.45f);
                    }
                    PlayArea.measure(this, bounds);
                    int maxX = Math.max(0, bounds.width() - placement.width);
                    int maxY = Math.max(0, bounds.height() - placement.height);
                    move(Math.max(0, Math.min(maxX, originX - Math.round(x - downX))),
                            Math.max(0, Math.min(maxY, originY - Math.round(y - downY))));
                    float speed = (float) Math.hypot(vx, vy);
                    if (food == this && event.getActionMasked() == MotionEvent.ACTION_UP) {
                        holding = false;
                        settle(!dragged);
                        if (dragged && time - lastMovement < 85 && speed >= dp(300)) {
                            float limit = Math.min(1, dp(3500) / speed);
                            slide.start(-vx * limit, -vy * limit);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                case MotionEvent.ACTION_CANCEL:
                    if (holding) settle(false);
                    holding = false;
                    return true;
                default:
                    return true;
            }
        }

        private float relativeX() {
            return placement.x + placement.width / 2f
                    - (pet.placement.x + pet.placement.width - dp(PetView.CENTER_X));
        }

        private float relativeY() {
            return placement.y + placement.height / 2f
                    - (pet.placement.y + pet.placement.height - dp(PetView.CENTER_Y));
        }

        private void move(int x, int y) {
            if (feedIfTouching(relativeX(), relativeY(), x - placement.x, y - placement.y)) return;
            if (x == placement.x && y == placement.y) return;
            placement.x = x;
            placement.y = y;
            windows.updateViewLayout(this, placement);
        }

        @Override protected void onDetachedFromWindow() {
            slide.stop();
            animate().cancel();
            if (wobble != null) wobble.cancel();
            super.onDetachedFromWindow();
        }
    }

    private final class SlideMotion {
        private static final float STOP_DP_PER_SECOND = 30;
        private final View owner;
        private final WindowManager.LayoutParams placement;
        private final BiConsumer<Integer, Integer> move;
        private final Rect displayFrame = new Rect();
        private final Runnable frame = this::advance;
        private float slideX;
        private float slideY;
        private float slideVelocityX;
        private float slideVelocityY;
        private long lastSlideFrameAt;

        SlideMotion(View owner, WindowManager.LayoutParams placement,
                    BiConsumer<Integer, Integer> move) {
            this.owner = owner;
            this.placement = placement;
            this.move = move;
        }

        private void start(float vx, float vy) {
            slideX = placement.x;
            slideY = placement.y;
            slideVelocityX = vx;
            slideVelocityY = vy;
            lastSlideFrameAt = SystemClock.uptimeMillis();
            owner.postOnAnimation(frame);
        }

        private void advance() {
            long now = SystemClock.uptimeMillis();
            float seconds = Math.min(32, now - lastSlideFrameAt) / 1000f;
            lastSlideFrameAt = now;
            float damping = (float) Math.exp(-SLIDE_FRICTION * seconds);
            float travel = (1 - damping) / SLIDE_FRICTION;

            PlayArea.measure(owner, displayFrame);
            int maxX = Math.max(0, displayFrame.width() - placement.width);
            int maxY = Math.max(0, displayFrame.height() - placement.height);
            slideX += slideVelocityX * travel;
            slideY += slideVelocityY * travel;
            slideVelocityX *= damping;
            slideVelocityY *= damping;
            if (slideX < 0 || slideX > maxX) {
                slideX = Math.max(0, Math.min(maxX, slideX));
                slideVelocityX = maxX == 0 ? 0 : -slideVelocityX * EDGE_BOUNCE;
            }
            if (slideY < 0 || slideY > maxY) {
                slideY = Math.max(0, Math.min(maxY, slideY));
                slideVelocityY = maxY == 0 ? 0 : -slideVelocityY * EDGE_BOUNCE;
            }
            move.accept(Math.round(slideX), Math.round(slideY));
            if (owner.isAttachedToWindow()
                    && Math.hypot(slideVelocityX, slideVelocityY) >= dp(STOP_DP_PER_SECOND)) {
                owner.postOnAnimation(frame);
            }
        }

        private void stop() {
            owner.removeCallbacks(frame);
        }

    }

    private final class PetView extends View {
        private static final long IDLE_MS = 20_000;
        private static final long HOLD_RING_DELAY_MS = 1000;
        private static final long HOLD_RING_FILL_MS = 3000;
        private static final long FOOD_HOLD_MS = HOLD_RING_DELAY_MS + HOLD_RING_FILL_MS;
        private static final long CHEW_MS = 1700;
        private static final long STARTLED_MS = 800;
        private static final long BUBBLE_MS = 1450;
        private static final long SETTLE_MS = 380;
        private static final long FAST_DRAG_GRACE_MS = 180;
        private static final long FAST_DRAG_TRIGGER_MS = 600;
        private static final float FAST_DRAG_DP_PER_MS = 0.65f;
        private static final long THROW_SAMPLE_MAX_AGE_MS = 85;
        private static final float MIN_THROW_DP_PER_SECOND = 450;
        private static final float MAX_THROW_DP_PER_SECOND = 4200;
        // Keep solo Bob's renderer self-contained.
        private static final float CENTER_X = 37f;
        private static final float CENTER_Y = 60f;
        private final android.graphics.Typeface face =
                android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD);
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path bubbleTail = new Path();
        private final Path accessoryPath = new Path();
        private final float density = getResources().getDisplayMetrics().density;
        private final WindowManager.LayoutParams placement;
        private final int touchSlop;
        private final Rect displayFrame = new Rect();
        private final SlideMotion slide;
        private final Runnable foodHold = () -> {
            tracking = false;
            showSnackPicker();
        };
        private float downX;
        private float downY;
        private long holdStartedAt;
        private float lastDragX;
        private float lastDragY;
        private long lastDragSampleAt;
        private long lastThrowSampleAt;
        private float throwVelocityX;
        private float throwVelocityY;
        private long fastDragStartedAt;
        private int dizzyLine;
        private long lastFastDragAt = -FAST_DRAG_GRACE_MS;
        private float targetTilt;
        private float dragTilt;
        private float dragStretch;
        private long releasedAt = -SETTLE_MS;
        private int startX;
        private int startY;
        private boolean dragging;
        private boolean tracking;
        private int reactionIndex = -1;
        private boolean showReaction;
        private long touchedAt = SystemClock.uptimeMillis() - STARTLED_MS;
        private long startedChewingAt = -CHEW_MS;

        PetView(WindowManager.LayoutParams placement) {
            super(PetService.this);
            this.placement = placement;
            slide = new SlideMotion(this, placement, this::placePet);
            touchSlop = Math.max(ViewConfiguration.get(getContext()).getScaledTouchSlop(), dp(13));
            setContentDescription("bob");
            setOnClickListener(view -> {
                if (isSleeping(SystemClock.uptimeMillis())) tryDropHat();
                closeSnackPicker();
                dismissSleepMessage();
                reactionIndex = (reactionIndex + 1) % REACTIONS.length;
                showReaction = true;
                touchedAt = SystemClock.uptimeMillis();
                progression.award("play", 5, 30 * 60_000L);
                progression.recordPlay();
                vibrateWithShake();
                invalidate();
            });
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    tracking = Math.hypot(event.getX() / density - CENTER_X,
                            event.getY() / density - CENTER_Y) <= 32;
                    if (!tracking) return false;
                    slide.stop();
                    downX = event.getRawX();
                    downY = event.getRawY();
                    holdStartedAt = event.getEventTime();
                    lastDragX = downX;
                    lastDragY = downY;
                    lastDragSampleAt = event.getEventTime();
                    lastThrowSampleAt = -THROW_SAMPLE_MAX_AGE_MS;
                    throwVelocityX = 0;
                    throwVelocityY = 0;
                    lastFastDragAt = -FAST_DRAG_GRACE_MS;
                    targetTilt = 0;
                    startX = placement.x;
                    startY = placement.y;
                    dragging = false;
                    postDelayed(foodHold, FOOD_HOLD_MS);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (tracking) movePet(event);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (tracking) {
                        movePet(event);
                        long heldFor = event.getEventTime() - holdStartedAt;
                        if (dragging) beginSlide(event.getEventTime());
                        else if (heldFor >= FOOD_HOLD_MS) foodHold.run();
                        else if (heldFor < HOLD_RING_DELAY_MS) performClick();
                    }
                    finishDrag();
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                case MotionEvent.ACTION_CANCEL:
                    finishDrag();
                    return true;
                default:
                    return true;
            }
        }

        private void finishDrag() {
            removeCallbacks(foodHold);
            if (dragging) {
                releasedAt = SystemClock.uptimeMillis();
            }
            tracking = false;
            dragging = false;
            invalidate();
        }

        private void movePet(MotionEvent event) {
            float dx = event.getRawX() - downX;
            float dy = event.getRawY() - downY;
            if (!dragging && Math.hypot(dx, dy) <= touchSlop) return;
            if (!dragging && showReaction) cancelTapVibration();
            removeCallbacks(foodHold);
            dragging = true;
            // A completed, intentional drag counts as a play session; rapid movement
            // events during the same gesture do not create extra XP.
            closeSnackPicker();
            dismissSleepMessage();
            showReaction = false;
            float movementX = event.getRawX() - lastDragX;
            float movementY = event.getRawY() - lastDragY;
            long sampleAt = event.getEventTime();
            long sampleDuration = Math.max(8, sampleAt - lastDragSampleAt);
            if (movementX != 0 || movementY != 0) {
                float weight = sampleAt - lastThrowSampleAt < THROW_SAMPLE_MAX_AGE_MS ? 0.6f : 1f;
                throwVelocityX += (movementX * 1000 / sampleDuration - throwVelocityX) * weight;
                throwVelocityY += (movementY * 1000 / sampleDuration - throwVelocityY) * weight;
                lastThrowSampleAt = sampleAt;
            }
            if (Math.hypot(movementX, movementY) / density >= FAST_DRAG_DP_PER_MS * sampleDuration) {
                if (sampleAt - lastFastDragAt >= FAST_DRAG_GRACE_MS) {
                    fastDragStartedAt = sampleAt;
                    dizzyLine = (dizzyLine + ThreadLocalRandom.current().nextInt(1, DIZZY_LINES.length)) % DIZZY_LINES.length;
                }
                lastFastDragAt = sampleAt;
            }
            if (movementX != 0) {
                targetTilt = Math.max(-14, Math.min(14, movementX / density * 1.7f));
            }
            lastDragX = event.getRawX();
            lastDragY = event.getRawY();
            lastDragSampleAt = sampleAt;
            PlayArea.measure(this, displayFrame);
            int maxX = Math.max(0, displayFrame.width() - placement.width);
            int maxY = Math.max(0, displayFrame.height() - placement.height);
            // The window is anchored to the right and bottom, so positive offsets move inward.
            int x = Math.max(0, Math.min(maxX, startX - Math.round(dx)));
            int y = Math.max(0, Math.min(maxY, startY - Math.round(dy)));
            placePet(x, y);
            touchedAt = SystemClock.uptimeMillis() - STARTLED_MS;
            invalidate();
        }

        private void beginSlide(long releasedAt) {
            float speed = (float) Math.hypot(throwVelocityX, throwVelocityY);
            if (releasedAt - lastThrowSampleAt >= THROW_SAMPLE_MAX_AGE_MS
                    || speed < MIN_THROW_DP_PER_SECOND * density) return;
            float limit = Math.min(1f, MAX_THROW_DP_PER_SECOND * density / speed);
            // Right/bottom window offsets run in the opposite direction from the touch.
            slide.start(-throwVelocityX * limit, -throwVelocityY * limit);
            progression.award("play", 5, 5 * 60_000L);
            progression.recordPlay();
        }

        @Override protected void onDetachedFromWindow() {
            slide.stop();
            removeCallbacks(foodHold);
            super.onDetachedFromWindow();
        }

        private void placePet(int x, int y) {
            if (x != placement.x || y != placement.y) {
                if (food != null) {
                    feedIfTouching(food.relativeX(), food.relativeY(), placement.x - x, placement.y - y);
                }
                placement.x = x;
                placement.y = y;
                windows.updateViewLayout(this, placement);
            }
        }

        private void fitOnScreen() {
            if (!isAttachedToWindow()) return;
            PlayArea.measure(this, displayFrame);
            placePet(Math.min(placement.x, Math.max(0, displayFrame.width() - placement.width)),
                    Math.min(placement.y, Math.max(0, displayFrame.height() - placement.height)));
        }

        private void startChewing() {
            startedChewingAt = SystemClock.uptimeMillis();
            touchedAt = startedChewingAt - STARTLED_MS;
            showReaction = false;
            invalidate();
        }

        private boolean isSleeping(long now) {
            return !dragging && now - touchedAt >= IDLE_MS && now - startedChewingAt >= CHEW_MS;
        }

        private PointF hatPosition(boolean sleeping) {
            PlayArea.measure(this, displayFrame);
            float x = displayFrame.width() - placement.width - placement.x + dp(CENTER_X);
            float y = displayFrame.height() - placement.height - placement.y + dp(CENTER_Y);
            return sleeping ? new PointF(x - dp(17), y - dp(19)) : new PointF(x, y - dp(26));
        }

        private boolean isInTopQuarter() {
            PlayArea.measure(this, displayFrame);
            return hatPosition(false).y <= displayFrame.height() * 0.25f;
        }

        @Override protected void onDraw(Canvas canvas) {
            long now = SystemClock.uptimeMillis();
            long elapsed = now - touchedAt;
            long ringElapsed = now - holdStartedAt - HOLD_RING_DELAY_MS;
            boolean showingHold = tracking && !dragging && ringElapsed >= 0;
            long chewElapsed = now - startedChewingAt;
            boolean chewing = chewElapsed < CHEW_MS;
            boolean fastDrag = dragging && now - lastFastDragAt < FAST_DRAG_GRACE_MS
                    && lastFastDragAt - fastDragStartedAt >= FAST_DRAG_TRIGGER_MS;
            boolean startled = !chewing && (fastDrag || elapsed < STARTLED_MS);
            boolean sleeping = isSleeping(now);
            long reactionElapsed = fastDrag ? now - fastDragStartedAt - FAST_DRAG_TRIGGER_MS : elapsed;
            float recoil = startled ? (fastDrag ? 0.8f : 1 - elapsed / (float) STARTLED_MS) : 0;
            float shake = (float) Math.sin(reactionElapsed * SHAKE_RATE) * 5 * recoil;
            float bounce = (float) Math.abs(Math.sin(reactionElapsed * 0.016)) * 8 * recoil;
            float breath = dragging ? 0
                    : (float) Math.sin(elapsed * 2 * Math.PI / 3600) * (sleeping ? 0.045f : 0.025f);
            float squash = (float) Math.sin(reactionElapsed * 0.032) * 0.09f * recoil;
            float settle = (now - releasedAt) / (float) SETTLE_MS;
            boolean settling = !dragging && settle < 1;
            if (dragging) {
                dragTilt += (targetTilt - dragTilt) * 0.28f;
                float targetStretch = fastDrag ? 0.04f : 0.10f;
                dragStretch += (targetStretch - dragStretch) * 0.28f;
            } else if (!settling) {
                dragTilt = 0;
                dragStretch = 0;
            }
            float wobble = settling
                    ? (float) Math.cos(settle * 3 * Math.PI) * (1 - settle) : 1;
            boolean foodReminder = showingFoodReminder(now);
            boolean speaking = showReaction && elapsed < BUBBLE_MS;
            canvas.save();
            canvas.scale(density, density);
            canvas.save();
            canvas.translate(CENTER_X + shake, CENTER_Y - bounce);
            canvas.rotate(dragTilt * wobble);
            float stretch = dragStretch * wobble;
            canvas.scale(1 + breath - squash - stretch, 1 + breath + squash + stretch);
            paint.setColor(0xff292538);
            canvas.drawCircle(0, 1, 26, paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(0, 0, 25, paint);

            canvas.save();
            if (sleeping || startled) canvas.rotate(-90);
            if (chewing) {
                drawText(canvas, chewElapsed % 360 < 180 ? ":o" : ":3", 0, 0, 23, 255);
            } else if (sleeping) {
                drawText(canvas, "-", -13, -2, 17, 255);
                drawText(canvas, "v", 0, 3, 17, 255);
                drawText(canvas, "-", 13, -2, 17, 255);
            } else {
                drawText(canvas, startled ? "@_@" : ":D", 0, 0, startled ? 17 : 23, 255);
            }
            canvas.restore();
            boolean detachedHat = hatRescue != null && hatRescue.hasDetachedHat();
            for (Accessory accessory : accessories) {
                if (!accessory.canFallOff() || !detachedHat)
                    accessory.draw(canvas, paint, accessoryPath, sleeping, startled);
            }
            canvas.restore();

            if (showingHold) drawHoldRing(canvas, Math.min(1f, ringElapsed / (float) HOLD_RING_FILL_MS));
            boolean snackPickerOpen = snackPicker != null;
            if (!snackPickerOpen && chewing) {
                float fade = Math.min(1f, (CHEW_MS - chewElapsed) / 250f);
                drawBubble(canvas, "nom nom", chewElapsed, fade, 34, CENTER_X, 1);
            } else if (!snackPickerOpen && foodReminder) {
                float pulse = (float) (0.72 + 0.28 * Math.sin((now - reminderStartedAt) * Math.PI / 360));
                drawBubble(canvas, "⭐ ‼️" + (reminderFood == null ? "" : reminderFood),
                        now - reminderStartedAt, 1, 37, CENTER_X, pulse);
            } else if (!snackPickerOpen && fastDrag) {
                drawBubble(canvas, DIZZY_LINES[dizzyLine], reactionElapsed, 1, 40, 43, 1);
            } else if (!snackPickerOpen && speaking) {
                float fade = Math.min(1f, (BUBBLE_MS - elapsed) / 250f);
                drawBubble(canvas, reactionIndex < 0 ? "" : REACTIONS[reactionIndex],
                        elapsed, fade, 29, CENTER_X, 1);
            }
            if (sleeping) {
                for (int index = 0; index < 3; index++) {
                    float phase = ((elapsed - IDLE_MS + index * 420) % 1260) / 1260f;
                    float drift = (float) Math.sin(phase * 2 * Math.PI) * 3;
                    drawText(canvas, "Z", 50 + 26 * phase + drift, 40 - 33 * phase,
                            9 + 9 * phase, (int) (255 * Math.sin(Math.PI * phase)));
                }
            }
            canvas.restore();

            if (foodReminder && now - reminderStartedAt >= 120_000) {
                reminderFood = null;
            }
            if (showingHold || chewing || startled || speaking || dragging || settling || foodReminder) {
                postInvalidateOnAnimation();
            }
            else postInvalidateDelayed(33);
        }

        private void drawHoldRing(Canvas canvas, float progress) {
            float radius = 28;
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.5f); paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(0x99847da1); canvas.drawCircle(CENTER_X, CENTER_Y, radius, paint);
            paint.setColor(0xff7651de);
            canvas.drawArc(CENTER_X-radius, CENTER_Y-radius, CENTER_X+radius, CENTER_Y+radius,
                    -90, 360*progress, false, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawBubble(Canvas canvas, String message, long elapsed, float exit,
                                float halfWidth, float centerX, float pulse) {
            float entry = Math.min(1f, elapsed / 140f);
            float spring = BUBBLE_POP.getInterpolation(entry);
            int alpha = Math.round(255 * entry * exit);
            canvas.save(); canvas.translate(centerX, 13 + 3 * (1 - entry));
            canvas.scale(.8f + .2f * spring, .55f + .45f * spring); canvas.scale(pulse, pulse);
            paint.setColor(0xff292538); paint.setAlpha(alpha);
            bubbleTail.reset(); bubbleTail.moveTo(-6, 7); bubbleTail.lineTo(2, 17); bubbleTail.lineTo(9, 7); bubbleTail.close();
            canvas.drawPath(bubbleTail, paint); canvas.drawRoundRect(-halfWidth, -11, halfWidth, 11, 9, 9, paint);
            paint.setColor(Color.WHITE); paint.setAlpha(alpha);
            canvas.drawRoundRect(-halfWidth+1.5f, -9.5f, halfWidth-1.5f, 9.5f, 7.5f, 7.5f, paint);
            drawText(canvas, message, 0, 0, 12, alpha); canvas.restore(); paint.setAlpha(255);
        }

        private void drawText(Canvas canvas, String text, float x, float y, float size, int alpha) {
            paint.setColor(0xff292538); paint.setAlpha(alpha); paint.setTypeface(face);
            paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(size);
            canvas.drawText(text, x, y - (paint.ascent() + paint.descent()) / 2, paint); paint.setAlpha(255);
        }

    }
}
