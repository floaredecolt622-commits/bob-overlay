package app.overlaypet;

import android.content.Context;
import android.content.SharedPreferences;

final class FoodChoices {
    // Fully qualified emoji in Unicode's Food & Drink group.
    static final Food[] OPTIONS = {
        new Food("🍇", "grapes"),
        new Food("🍈", "melon"),
        new Food("🍉", "watermelon"),
        new Food("🍊", "tangerine"),
        new Food("🍋", "lemon"),
        new Food("🍋‍🟩", "lime"),
        new Food("🍌", "banana"),
        new Food("🍍", "pineapple"),
        new Food("🥭", "mango"),
        new Food("🍎", "red apple"),
        new Food("🍏", "green apple"),
        new Food("🍐", "pear"),
        new Food("🍑", "peach"),
        new Food("🍒", "cherries"),
        new Food("🍓", "strawberry"),
        new Food("🫐", "blueberries"),
        new Food("🥝", "kiwi fruit"),
        new Food("🍅", "tomato"),
        new Food("🫒", "olive"),
        new Food("🥥", "coconut"),
        new Food("🥑", "avocado"),
        new Food("🍆", "eggplant"),
        new Food("🥔", "potato"),
        new Food("🥕", "carrot"),
        new Food("🌽", "ear of corn"),
        new Food("🌶️", "hot pepper"),
        new Food("🫑", "bell pepper"),
        new Food("🥒", "cucumber"),
        new Food("🫝", "pickle"),
        new Food("🥬", "leafy green"),
        new Food("🥦", "broccoli"),
        new Food("🧄", "garlic"),
        new Food("🧅", "onion"),
        new Food("🥜", "peanuts"),
        new Food("🫘", "beans"),
        new Food("🌰", "chestnut"),
        new Food("🫚", "ginger root"),
        new Food("🫛", "pea pod"),
        new Food("🍄‍🟫", "brown mushroom"),
        new Food("🫜", "root vegetable"),
        new Food("🍞", "bread"),
        new Food("🥐", "croissant"),
        new Food("🥖", "baguette bread"),
        new Food("🫓", "flatbread"),
        new Food("🥨", "pretzel"),
        new Food("🥯", "bagel"),
        new Food("🥞", "pancakes"),
        new Food("🧇", "waffle"),
        new Food("🧀", "cheese wedge"),
        new Food("🍖", "meat on bone"),
        new Food("🍗", "poultry leg"),
        new Food("🥩", "cut of meat"),
        new Food("🥓", "bacon"),
        new Food("🍔", "hamburger"),
        new Food("🍟", "french fries"),
        new Food("🍕", "pizza"),
        new Food("🌭", "hot dog"),
        new Food("🥪", "sandwich"),
        new Food("🌮", "taco"),
        new Food("🌯", "burrito"),
        new Food("🫔", "tamale"),
        new Food("🥙", "stuffed flatbread"),
        new Food("🧆", "falafel"),
        new Food("🥚", "egg"),
        new Food("🍳", "cooking"),
        new Food("🥘", "shallow pan of food"),
        new Food("🍲", "pot of food"),
        new Food("🫕", "fondue"),
        new Food("🥣", "bowl with spoon"),
        new Food("🥗", "green salad"),
        new Food("🍿", "popcorn"),
        new Food("🧈", "butter"),
        new Food("🧂", "salt"),
        new Food("🥫", "canned food"),
        new Food("🍱", "bento box"),
        new Food("🍘", "rice cracker"),
        new Food("🍙", "rice ball"),
        new Food("🍚", "cooked rice"),
        new Food("🍛", "curry rice"),
        new Food("🍜", "steaming bowl"),
        new Food("🍝", "spaghetti"),
        new Food("🍠", "roasted sweet potato"),
        new Food("🍢", "oden"),
        new Food("🍣", "sushi"),
        new Food("🍤", "fried shrimp"),
        new Food("🍥", "fish cake with swirl"),
        new Food("🥮", "moon cake"),
        new Food("🍡", "dango"),
        new Food("🥟", "dumpling"),
        new Food("🥠", "fortune cookie"),
        new Food("🥡", "takeout box"),
        new Food("🍦", "soft ice cream"),
        new Food("🍧", "shaved ice"),
        new Food("🍨", "ice cream"),
        new Food("🍩", "doughnut"),
        new Food("🍪", "cookie"),
        new Food("🎂", "birthday cake"),
        new Food("🍰", "shortcake"),
        new Food("🧁", "cupcake"),
        new Food("🥧", "pie"),
        new Food("🍫", "chocolate bar"),
        new Food("🍬", "candy"),
        new Food("🍭", "lollipop"),
        new Food("🍮", "custard"),
        new Food("🍯", "honey pot"),
        new Food("🍼", "baby bottle"),
        new Food("🥛", "glass of milk"),
        new Food("☕", "hot beverage"),
        new Food("🫖", "teapot"),
        new Food("🍵", "teacup without handle"),
        new Food("🍶", "sake"),
        new Food("🍾", "bottle with popping cork"),
        new Food("🍷", "wine glass"),
        new Food("🍸", "cocktail glass"),
        new Food("🍹", "tropical drink"),
        new Food("🍺", "beer mug"),
        new Food("🍻", "clinking beer mugs"),
        new Food("🥂", "clinking glasses"),
        new Food("🥃", "tumbler glass"),
        new Food("🫗", "pouring liquid"),
        new Food("🥤", "cup with straw"),
        new Food("🧋", "bubble tea"),
        new Food("🧃", "beverage box"),
        new Food("🧉", "mate"),
        new Food("🧊", "ice"),
        new Food("🥢", "chopsticks"),
        new Food("🍽️", "fork and knife with plate"),
        new Food("🍴", "fork and knife"),
        new Food("🥄", "spoon"),
        new Food("🔪", "kitchen knife"),
        new Food("🫙", "jar"),
        new Food("🏺", "amphora")
    };
    private static final String[] DEFAULTS = {"🍉", "🍇", "🍡", "🍗"};
    static final int SLOT_COUNT = DEFAULTS.length;

    static int selectedIndex(Context context, int slot) {
        String emoji = preferences(context).getString("slot_" + slot, DEFAULTS[slot]);
        int index = indexOf(emoji);
        return index >= 0 ? index : defaultIndex(slot);
    }

    static int defaultIndex(int slot) {
        return indexOf(DEFAULTS[slot]);
    }

    static void save(Context context, int[] selections) {
        SharedPreferences.Editor editor = preferences(context).edit();
        for (int slot = 0; slot < SLOT_COUNT; slot++) {
            editor.putString("slot_" + slot, OPTIONS[selections[slot]].emoji);
        }
        editor.apply();
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences("food_choices", Context.MODE_PRIVATE);
    }

    private static int indexOf(String emoji) {
        for (int index = 0; index < OPTIONS.length; index++) {
            if (OPTIONS[index].emoji.equals(emoji)) return index;
        }
        return -1;
    }

    static final class Food {
        final String emoji;
        final String name;

        Food(String emoji, String name) {
            this.emoji = emoji;
            this.name = name;
        }

        @Override public String toString() {
            return emoji + "  " + name;
        }
    }

    private FoodChoices() {}
}
