package app.overlaypet;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.animation.OvershootInterpolator;
import java.util.EnumSet;

/** Bob artwork and animation renderer. */
final class BobRenderer {
    static final float CENTER_X = 37f;
    static final float CENTER_Y = 60f;
    private static final long IDLE_MS = 20_000;
    private static final long CHEW_MS = 1700;
    private static final long BUBBLE_MS = 1450;
    private static final OvershootInterpolator BUBBLE_POP = new OvershootInterpolator(1.25f);
    private static final android.graphics.Typeface FACE = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD);

    static final class Frame {
        long elapsed, ringElapsed, chewElapsed, reactionElapsed, reminderElapsed;
        boolean showingHold, chewing, fastDrag, startled, sleeping, dragging, settling;
        boolean foodReminder, speaking, snackPickerOpen, detachedHat;
        float shake, bounce, breath, squash, dragTilt, dragStretch, wobble;
        float holdProgress, reminderPulse = 1;
        String face = ":D", reaction = "", reminderFood = "", label = "";
        EnumSet<Accessory> accessories = EnumSet.noneOf(Accessory.class);
    }

    static void draw(Canvas canvas, Paint paint, Path accessoryPath, Path bubbleTail,
                     float density, Frame f) {
        canvas.save();
        canvas.scale(density, density);
        if (f.label != null && !f.label.isEmpty()) drawText(canvas, paint, f.label, CENTER_X, 12, 10, 255);
        canvas.save();
        canvas.translate(CENTER_X + f.shake, CENTER_Y - f.bounce);
        canvas.rotate(f.dragTilt * f.wobble);
        float stretch = f.dragStretch * f.wobble;
        canvas.scale(1 + f.breath - f.squash - stretch, 1 + f.breath + f.squash + stretch);
        paint.setColor(0xff292538);
        canvas.drawCircle(0, 1, 26, paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(0, 0, 25, paint);

        canvas.save();
        if (f.sleeping || f.startled) canvas.rotate(-90);
        if (f.chewing) {
            String face = f.chewElapsed % 360 < 180 ? ":o" : ":3";
            drawText(canvas, paint, face, 0, 0, 23, 255);
        } else if (f.sleeping) {
            drawText(canvas, paint, "-", -13, -2, 17, 255);
            drawText(canvas, paint, "v", 0, 3, 17, 255);
            drawText(canvas, paint, "-", 13, -2, 17, 255);
        } else {
            drawText(canvas, paint, f.startled ? "@_@" : ":D", 0, 0, f.startled ? 17 : 23, 255);
        }
        canvas.restore();
        for (Accessory accessory : f.accessories) {
            if (!accessory.canFallOff() || !f.detachedHat) accessory.draw(canvas, paint, accessoryPath, f.sleeping, f.startled);
        }
        canvas.restore();

        if (f.showingHold) drawHoldRing(canvas, paint, f.holdProgress);
        if (!f.snackPickerOpen && f.chewing) {
            float fade = Math.min(1f, (CHEW_MS - f.chewElapsed) / 250f);
            drawBubble(canvas, paint, bubbleTail, "nom nom", f.chewElapsed, fade, 34, CENTER_X, 1);
        } else if (!f.snackPickerOpen && f.foodReminder) {
            drawBubble(canvas, paint, bubbleTail, "⭐ ‼️" + f.reminderFood,
                    f.reminderElapsed, 1, 37, CENTER_X, f.reminderPulse);
        } else if (!f.snackPickerOpen && f.fastDrag) {
            drawBubble(canvas, paint, bubbleTail, "WHOAAAAA!", f.reactionElapsed, 1, 40, 43, 1);
        } else if (!f.snackPickerOpen && f.speaking) {
            float fade = Math.min(1f, (BUBBLE_MS - f.elapsed) / 250f);
            drawBubble(canvas, paint, bubbleTail, f.reaction, f.elapsed, fade, 29, CENTER_X, 1);
        }
        if (f.sleeping) {
            for (int index = 0; index < 3; index++) {
                float phase = ((f.elapsed - IDLE_MS + index * 420) % 1260) / 1260f;
                float drift = (float) Math.sin(phase * 2 * Math.PI) * 3;
                drawText(canvas, paint, "Z", 50 + 26 * phase + drift, 40 - 33 * phase,
                        9 + 9 * phase, (int) (255 * Math.sin(Math.PI * phase)));
            }
        }
        canvas.restore();
    }

    private static void drawHoldRing(Canvas canvas, Paint paint, float progress) {
        float radius = 28;
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.5f); paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0x99847da1); canvas.drawCircle(CENTER_X, CENTER_Y, radius, paint);
        paint.setColor(0xff7651de);
        canvas.drawArc(CENTER_X-radius,CENTER_Y-radius,CENTER_X+radius,CENTER_Y+radius,-90,360*progress,false,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private static void drawBubble(Canvas canvas, Paint paint, Path tail, String message, long elapsed,
                                   float exit, float halfWidth, float centerX, float pulse) {
        float entry = Math.min(1f, elapsed / 140f);
        float spring = BUBBLE_POP.getInterpolation(entry);
        int alpha = Math.round(255 * entry * exit);
        canvas.save(); canvas.translate(centerX,13+3*(1-entry));
        canvas.scale(.8f+.2f*spring,.55f+.45f*spring); canvas.scale(pulse,pulse);
        paint.setColor(0xff292538); paint.setAlpha(alpha);
        tail.reset(); tail.moveTo(-6,7); tail.lineTo(2,17); tail.lineTo(9,7); tail.close();
        canvas.drawPath(tail,paint); canvas.drawRoundRect(-halfWidth,-11,halfWidth,11,9,9,paint);
        paint.setColor(Color.WHITE); paint.setAlpha(alpha);
        canvas.drawRoundRect(-halfWidth+1.5f,-9.5f,halfWidth-1.5f,9.5f,7.5f,7.5f,paint);
        drawText(canvas,paint,message,0,0,12,alpha); canvas.restore(); paint.setAlpha(255);
    }

    private static void drawText(Canvas canvas, Paint paint, String text, float x, float y, float size, int alpha) {
        paint.setColor(0xff292538); paint.setAlpha(alpha); paint.setTypeface(FACE);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(size);
        canvas.drawText(text,x,y-(paint.ascent()+paint.descent())/2,paint); paint.setAlpha(255);
    }

    private BobRenderer() {}
}
