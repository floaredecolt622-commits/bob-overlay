package app.overlaypet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

final class HatRescue {
    private static final long RESCUE_DELAY_MS = 60_000;
    static final String DROPS_ENABLED = "accessory_drops_enabled";
    private static final float GRAVITY_DP_PER_SECOND_SQUARED = 1900;
    private static final float SANTA_GRAVITY_DP_PER_SECOND_SQUARED = 850;
    private static final float FLOOR_RESTITUTION = 0.22f;
    private static final float CROWN_KICK_DP_PER_SECOND = 300;
    private static final float THROW_LIMIT_DP_PER_SECOND = 2200;
    private static final float MIN_THROW_DP_PER_SECOND = 180;
    private static final long LANDING_MS = 160;
    private static final long TWO_PATS_MS = 760;
    private static final long APPROACH_MS = 1650;
    private static final long CARRY_MS = 1900;
    private static final long LEAVE_MS = 1200;
    private final View bob;
    private final WindowManager windows;
    private final Accessory accessory;
    private final Supplier<PointF> hatPosition;
    private final BooleanSupplier bobIsSleeping;
    private final Runnable finished;
    private final java.util.function.IntConsumer trickshotReturned;
    private final Runnable trickshotFailed;
    private final Rect frame = new Rect();
    private final float density;
    private final Sprite hat;
    private Sprite star;
    private boolean returned;
    private boolean trickshotCatch;
    private int wallContacts;

    HatRescue(View bob, WindowManager windows, Accessory accessory,
              Supplier<PointF> hatPosition, BooleanSupplier bobIsSleeping, Runnable finished,
              java.util.function.IntConsumer trickshotReturned, Runnable trickshotFailed) {
        this.bob = bob;
        this.windows = windows;
        this.accessory = accessory;
        this.hatPosition = hatPosition;
        this.bobIsSleeping = bobIsSleeping;
        this.finished = finished;
        this.trickshotReturned = trickshotReturned;
        this.trickshotFailed = trickshotFailed;
        density = bob.getResources().getDisplayMetrics().density;
        hat = new Sprite(bob.getContext(), false);
    }

    private enum Phase {
        WAITING, APPROACHING, CARRYING, LANDING, PATTING, LEAVING
    }

    private Phase phase = Phase.WAITING;
    private long phaseStarted;
    private float startX;
    private float startY;
    private float entryX;
    private float dragX;
    private float dragY;
    private float grabbedAtX;
    private float grabbedAtY;
    private boolean dragging;
    private boolean falling;
    private boolean thrown;
    private float landingStartAngle;
    private boolean rescueScheduled;
    private float fallStartY;
    private float fallStartAngle;
    private long fallStartedAt;
    private long lastFallElapsed;
    private float fallVelocityX;
    private float fallVelocityY;
    private float lastSway;
    private float lastTouchX;
    private float lastTouchY;
    private long lastTouchTime;
    private float dragVelocityX;
    private float dragVelocityY;
    private final Runnable animate = this::advance;
    private final Runnable sendStar = this::startRescue;

    boolean start(PointF origin) {
        PlayArea.measure(bob, frame);
        if (frame.height() - origin.y < dp(125)) return false;
        hat.angle = -42;
        hat.locate(origin.x, origin.y);
        if (!hat.add()) return false;
        hat.setInteractive(true);
        float kick = accessory == Accessory.CROWN ? dp(CROWN_KICK_DP_PER_SECOND) : 0;
        beginFall(-kick * 0.6f, -kick, false);
        return true;
    }

    boolean hasDetachedHat() {
        return !returned;
    }

    void close() {
        bob.removeCallbacks(animate);
        bob.removeCallbacks(sendStar);
        hat.remove();
        if (star != null) star.remove();
    }

    private float dp(float value) {
        return value * density;
    }

    private void startRescue() {
        if (phase != Phase.WAITING) return;
        PlayArea.measure(bob, frame);
        star = new Sprite(bob.getContext(), true);
        entryX = hat.x < frame.width() / 2f ? -dp(26) : frame.width() + dp(26);
        startY = Math.max(dp(24), hat.y - dp(135));
        star.locate(entryX, startY);
        if (!star.add()) return;
        phase = Phase.APPROACHING;
        phaseStarted = SystemClock.uptimeMillis();
        requestFrame();
    }

    private void advance() {
        PlayArea.measure(bob, frame);
        long now = SystemClock.uptimeMillis();
        long elapsed = now - phaseStarted;
        if (falling) {
            float previousX = hat.x;
            float previousY = hat.y;
            boolean settled = advanceFall(now - fallStartedAt);
            if (thrown && catchAlongPath(previousX, previousY)) return;
            if (settled) {
                if (thrown) trickshotFailed.run();
                falling = false;
                thrown = false;
                if (!rescueScheduled) {
                    rescueScheduled = true;
                    bob.postDelayed(sendStar, RESCUE_DELAY_MS);
                }
            }
        }
        switch (phase) {
            case WAITING:
                if (!falling) return;
                break;
            case APPROACHING:
                float approach = smooth(progress(elapsed, APPROACH_MS));
                star.locate(mix(entryX, hat.x, approach),
                        mix(startY, hat.y - dp(21), approach));
                if (approach == 1 && !dragging && !falling) {
                    startX = hat.x;
                    startY = hat.y;
                    hat.setInteractive(false);
                    phase = Phase.CARRYING;
                    phaseStarted = SystemClock.uptimeMillis();
                }
                break;
            case CARRYING:
                float carry = smooth(progress(elapsed, CARRY_MS));
                PointF target = hatPosition.get();
                float x = mix(startX, target.x, carry);
                float y = mix(startY, target.y, carry) - dp(24) * (float) Math.sin(Math.PI * carry);
                hat.locate(x, y);
                star.locate(x, y - dp(21));
                if (carry == 1) returnHat();
                break;
            case LANDING:
                float landing = eased(progress(elapsed, LANDING_MS));
                PointF perch = hatPosition.get();
                hat.angle = mix(landingStartAngle, bobIsSleeping.getAsBoolean() ? -42 : 0, landing);
                hat.locate(mix(startX, perch.x, landing), mix(startY, perch.y, landing));
                if (landing == 1) {
                    returnHat();
                    if (star == null || !star.attached) return;
                }
                break;
            case PATTING:
                if (elapsed >= TWO_PATS_MS || !bobIsSleeping.getAsBoolean()) {
                    beginLeaving();
                    break;
                }
                float patPhase = (elapsed % 460) / 460f;
                float dip = (float) Math.pow(Math.sin(Math.PI * patPhase), 2);
                dip *= Math.min(1, elapsed / 100f) * Math.min(1, (TWO_PATS_MS - elapsed) / 100f);
                PointF head = hatPosition.get();
                star.locate(head.x, head.y - dp(21) + dp(9) * dip);
                break;
            case LEAVING:
                float leave = smooth(progress(elapsed, LEAVE_MS));
                float edge = entryX < 0 ? -dp(26) : frame.width() + dp(26);
                star.locate(mix(startX, edge, leave), mix(startY, startY - dp(85), leave));
                if (leave == 1) {
                    finished.run();
                    return;
                }
                break;
        }
        bob.postOnAnimation(animate);
    }

    private void requestFrame() {
        bob.removeCallbacks(animate);
        bob.postOnAnimation(animate);
    }

    private void beginFall(float vx, float vy, boolean thrown) {
        falling = true;
        this.thrown = thrown;
        if (thrown) wallContacts = 0;
        fallStartY = Math.min(hat.y, frame.height() - dp(12));
        fallStartAngle = hat.angle;
        float maxUp = (float) Math.sqrt(2 * gravity()
                * Math.max(0, fallStartY - dp(12)));
        fallVelocityX = vx;
        fallVelocityY = Math.max(-maxUp, vy);
        lastFallElapsed = 0;
        lastSway = 0;
        fallStartedAt = SystemClock.uptimeMillis();
        requestFrame();
    }

    private boolean catchAlongPath(float previousX, float previousY) {
        PointF perch = hatPosition.get();
        float dx = hat.x - previousX;
        float dy = hat.y - previousY;
        float distanceSquared = dx * dx + dy * dy;
        float fraction = distanceSquared == 0 ? 0 : Math.max(0, Math.min(1,
                ((perch.x - previousX) * dx + (perch.y - previousY) * dy) / distanceSquared));
        float x = previousX + fraction * dx;
        float y = previousY + fraction * dy;
        if (Math.hypot(x - perch.x, y - perch.y) > dp(25)) return false;
        beginLanding(x, y);
        return true;
    }

    private void beginLanding(float x, float y) {
        trickshotCatch = thrown;
        falling = false;
        thrown = false;
        dragging = false;
        bob.removeCallbacks(sendStar);
        hat.setInteractive(false);
        startX = x;
        startY = y;
        landingStartAngle = hat.angle;
        phase = Phase.LANDING;
        phaseStarted = SystemClock.uptimeMillis();
        requestFrame();
    }

    private boolean advanceFall(long elapsed) {
        float floor = Math.max(dp(12), frame.height() - dp(12));
        float gravity = gravity();
        float seconds = elapsed / 1000f;
        float impactSpeed = (float) Math.sqrt(fallVelocityY * fallVelocityY
                + 2 * gravity * Math.max(0, floor - fallStartY));
        float impactTime = (impactSpeed - fallVelocityY) / gravity;
        long previousFallElapsed = lastFallElapsed;
        float stepSeconds = Math.min(32, elapsed - lastFallElapsed) / 1000f;
        lastFallElapsed = elapsed;
        float damping = (float) Math.exp(-PetService.SLIDE_FRICTION * stepSeconds);
        float fall = impactTime > 0 ? Math.min(1, seconds / impactTime) : 1;
        float sway = accessory == Accessory.SANTA_HAT
                ? (float) (Math.sin(4 * Math.PI * fall) * Math.sin(Math.PI * fall)) : 0;
        float x = hat.x + fallVelocityX * (1 - damping) / PetService.SLIDE_FRICTION
                + dp(11) * (sway - lastSway);
        lastSway = sway;
        fallVelocityX *= damping;
        float left = Math.min(dp(16), frame.width() / 2f);
        float right = frame.width() - left;
        if (x < left || x > right) {
            x = Math.max(left, Math.min(right, x));
            fallVelocityX = -fallVelocityX * PetService.EDGE_BOUNCE;
            wallContacts++;
        }
        if (seconds >= impactTime && previousFallElapsed < impactTime) wallContacts++;
        if (seconds < impactTime) {
            float tilt = accessory == Accessory.SANTA_HAT ? 16 * sway
                    : 20 * (float) Math.sin(2 * Math.PI * fall);
            hat.angle = mix(fallStartAngle, 0, fall) + tilt;
            hat.locate(x, fallStartY + fallVelocityY * seconds + 0.5f * gravity * seconds * seconds);
            return false;
        }

        float bounceTime = seconds - impactTime;
        float reboundSpeed = impactSpeed * FLOOR_RESTITUTION;
        float height = Math.max(0, reboundSpeed * bounceTime - 0.5f * gravity * bounceTime * bounceTime);
        hat.angle = 0;
        hat.locate(x, floor - height);
        return bounceTime >= 2 * reboundSpeed / gravity && Math.abs(fallVelocityX) < dp(30);
    }

    private float gravity() {
        return dp(accessory == Accessory.SANTA_HAT
                ? SANTA_GRAVITY_DP_PER_SECOND_SQUARED : GRAVITY_DP_PER_SECOND_SQUARED);
    }

    private void returnHat() {
        if (returned) return;
        returned = true;
        if (trickshotCatch) trickshotReturned.accept(wallContacts);
        hat.remove();
        bob.invalidate();
        if (star == null || !star.attached) {
            finished.run();
            return;
        }
        if (phase == Phase.CARRYING && bobIsSleeping.getAsBoolean()) {
            phase = Phase.PATTING;
            phaseStarted = SystemClock.uptimeMillis();
        } else {
            beginLeaving();
        }
    }

    private void beginLeaving() {
        startX = star.x;
        startY = star.y;
        phase = Phase.LEAVING;
        phaseStarted = SystemClock.uptimeMillis();
    }

    private boolean moveHat(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (phase != Phase.WAITING && phase != Phase.APPROACHING) return false;
                dragging = true;
                falling = false;
                dragX = hat.x;
                dragY = hat.y;
                grabbedAtX = event.getRawX();
                grabbedAtY = event.getRawY();
                lastTouchX = grabbedAtX;
                lastTouchY = grabbedAtY;
                lastTouchTime = event.getEventTime();
                dragVelocityX = 0;
                dragVelocityY = 0;
                return true;
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_UP:
                if (!dragging) return true;
                PlayArea.measure(bob, frame);
                float x = Math.max(0, Math.min(frame.width(), dragX + event.getRawX() - grabbedAtX));
                float y = Math.max(0, Math.min(frame.height(), dragY + event.getRawY() - grabbedAtY));
                updateDragVelocity(event);
                hat.locate(x, y);
                PointF target = hatPosition.get();
                if (Math.hypot(x - target.x, y - target.y - dp(18)) <= dp(39)) {
                    beginLanding(x, y);
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    dragging = false;
                    if (event.getEventTime() - lastTouchTime < 85
                            && Math.hypot(dragVelocityX, dragVelocityY) >= dp(MIN_THROW_DP_PER_SECOND)) {
                        beginFall(dragVelocityX, dragVelocityY, true);
                    } else {
                        beginFall(0, 0, false);
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (dragging) beginFall(0, 0, false);
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    private void updateDragVelocity(MotionEvent event) {
        float dx = event.getRawX() - lastTouchX;
        float dy = event.getRawY() - lastTouchY;
        if (dx == 0 && dy == 0) return;
        long interval = event.getEventTime() - lastTouchTime;
        float seconds = Math.max(8, interval) / 1000f;
        float weight = interval < 85 ? 0.6f : 1f;
        dragVelocityX += (dx / seconds - dragVelocityX) * weight;
        dragVelocityY += (dy / seconds - dragVelocityY) * weight;
        double speed = Math.hypot(dragVelocityX, dragVelocityY);
        if (speed > dp(THROW_LIMIT_DP_PER_SECOND)) {
            float limit = (float) (dp(THROW_LIMIT_DP_PER_SECOND) / speed);
            dragVelocityX *= limit;
            dragVelocityY *= limit;
        }
        lastTouchX = event.getRawX();
        lastTouchY = event.getRawY();
        lastTouchTime = event.getEventTime();
    }

    private static float progress(long elapsed, long duration) {
        return Math.min(1f, elapsed / (float) duration);
    }

    private static float eased(float value) {
        return value * value * (3 - 2 * value);
    }

    private static float smooth(float value) {
        value = Math.max(0, Math.min(1, value));
        return value * value * value * (value * (value * 6 - 15) + 10);
    }

    private static float mix(float start, float end, float progress) {
        return start + (end - start) * progress;
    }

    private final class Sprite extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final boolean isStar;
        private final WindowManager.LayoutParams placement;
        private boolean attached;
        private float x;
        private float y;
        private float localX;
        private float localY;
        private float angle;

        Sprite(Context context, boolean isStar) {
            super(context);
            this.isStar = isStar;
            int size = Math.round(dp(52));
            placement = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT);
            PlayArea.fitOverlay(placement);
            placement.gravity = Gravity.BOTTOM | Gravity.RIGHT;
            placement.alpha = 0.8f;
            setContentDescription(isStar ? "Helping star" : "Fallen " + accessory.label);
        }

        boolean add() {
            try {
                windows.addView(this, placement);
                attached = true;
                return true;
            } catch (SecurityException | WindowManager.BadTokenException error) {
                return false;
            }
        }

        void remove() {
            if (!attached) return;
            windows.removeView(this);
            attached = false;
        }

        void setInteractive(boolean interactive) {
            if (interactive) placement.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else placement.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            placement.alpha = interactive ? 1 : 0.8f;
            windows.updateViewLayout(this, placement);
        }

        void locate(float x, float y) {
            this.x = x;
            this.y = y;
            int left = Math.max(0, Math.min(frame.width() - placement.width,
                    Math.round(x - placement.width / 2f)));
            int top = Math.max(0, Math.min(frame.height() - placement.height,
                    Math.round(y - placement.height / 2f)));
            int offsetX = Math.max(0, frame.width() - placement.width - left);
            int offsetY = Math.max(0, frame.height() - placement.height - top);
            localX = x - left;
            localY = y - top;
            boolean moved = offsetX != placement.x || offsetY != placement.y;
            placement.x = offsetX;
            placement.y = offsetY;
            if (moved && attached) windows.updateViewLayout(this, placement);
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            return !isStar && moveHat(event);
        }

        @Override protected void onDraw(Canvas canvas) {
            canvas.save();
            canvas.translate(localX, localY);
            canvas.scale(density, density);
            if (isStar) {
                paint.setTextSize(25);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("⭐", 0, -(paint.ascent() + paint.descent()) / 2, paint);
            } else {
                canvas.rotate(angle);
                canvas.translate(0, 26);
                accessory.draw(canvas, paint, path, false, false);
            }
            canvas.restore();
        }
    }
}
