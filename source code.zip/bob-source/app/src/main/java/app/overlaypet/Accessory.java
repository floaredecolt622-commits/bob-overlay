package app.overlaypet;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

enum Accessory {
    NONE("None", 1),
    HAT("🎩  Tiny hat", 1),
    BOW_TIE("🎀  Bow tie", 1),
    SUNGLASSES("🕶️  Sunglasses", 1),
    FLOWER("🌸  Flower", 1),
    HEADPHONES("🎧  Headphones", 1),
    CROWN("👑  Crown", 1),
    SANTA_HAT("🎅  Santa hat", 1),
    STAR_HAT("🌟  Star hat", 3),
    RAINBOW_HAT("🌈  Rainbow hat", 8),
    WITCH_HAT("🧙  Witch hat", 5),
    CLOUD_HAT("☁️  Cloud cap", 12),
    GOLD_HAT("✨  Golden topper", 20),
    SCARF("🧣  Cozy scarf", 21),
    HALO("😇  Halo", 22),
    WINGS("🪽  Tiny wings", 23),
    BACKPACK("🎒  Mini backpack", 24),
    HEART_PIN("💖  Heart pin", 25);

    private static final String KEY = "accessory";
    private static final String COMBO_KEY = "accessory_combo";
    final String label;
    final int unlockLevel;

    Accessory(String label, int unlockLevel) {
        this.label = label;
        this.unlockLevel = unlockLevel;
    }

    static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences("appearance", Context.MODE_PRIVATE);
    }

    static EnumSet<Accessory> selected(Context context) {
        SharedPreferences preferences = preferences(context);
        Set<String> saved = preferences.getStringSet(COMBO_KEY, null);
        if (saved == null) {
            saved = java.util.Collections.singleton(preferences.getString(KEY, NONE.name()));
        }
        EnumSet<Accessory> selection = EnumSet.noneOf(Accessory.class);
        for (Accessory accessory : values()) {
            if (accessory != NONE && saved.contains(accessory.name())
                    && unlocked(context, accessory)) selection.add(accessory);
        }
        Accessory headwear = headwear(selection);
        selection.removeIf(accessory -> accessory.canFallOff() && accessory != headwear);
        return selection;
    }

    static void save(Context context, EnumSet<Accessory> selection) {
        Set<String> saved = new HashSet<>();
        for (Accessory accessory : selection) saved.add(accessory.name());
        preferences(context).edit().putStringSet(COMBO_KEY, saved).apply();
    }

    static boolean unlocked(Context context, Accessory accessory) {
        boolean leveling = preferences(context).getBoolean(Progression.ENABLED, false);
        // Legacy accessories remain available without progression. The five recent
        // collectibles are explicitly level-gated, even when leveling is toggled off.
        if (!leveling && accessory.unlockLevel < 21) return true;
        Set<String> unlocked = preferences(context).getStringSet(
                "unlocked_accessories", java.util.Collections.singleton("HAT"));
        if (unlocked.contains(accessory.name())) return true;
        return new Progression(context).level() >= accessory.unlockLevel;
    }

    static Accessory headwear(EnumSet<Accessory> selection) {
        if (selection.contains(GOLD_HAT)) return GOLD_HAT;
        if (selection.contains(CLOUD_HAT)) return CLOUD_HAT;
        if (selection.contains(WITCH_HAT)) return WITCH_HAT;
        if (selection.contains(RAINBOW_HAT)) return RAINBOW_HAT;
        if (selection.contains(STAR_HAT)) return STAR_HAT;
        if (selection.contains(SANTA_HAT)) return SANTA_HAT;
        if (selection.contains(CROWN)) return CROWN;
        if (selection.contains(HAT)) return HAT;
        return NONE;
    }

    boolean canFallOff() {
        return this == HAT || this == CROWN || this == SANTA_HAT
                || this == STAR_HAT || this == RAINBOW_HAT || this == WITCH_HAT
                || this == CLOUD_HAT || this == GOLD_HAT;
    }

    void draw(Canvas canvas, Paint paint, Path path, boolean sleeping, boolean startled) {
        canvas.save();
        if (canFallOff()) {
            // Tilt around bob's center so the headwear rests on the upper-left edge.
            if (sleeping) canvas.rotate(-42);
            canvas.translate(0, 5);
        }
        switch (this) {
            case HAT:
                paint.setColor(0xff292538);
                canvas.drawRoundRect(-9, -39, 9, -24, 3, 3, paint);
                paint.setColor(0xff9164e8);
                canvas.drawRect(-9, -29, 9, -25, paint);
                paint.setColor(0xff292538);
                canvas.drawRoundRect(-14, -25, 14, -21, 2, 2, paint);
                break;
            case SANTA_HAT:
                path.rewind();
                path.moveTo(-12, -24);
                path.cubicTo(-9, -34, -3, -43, 6, -42);
                path.cubicTo(12, -42, 16, -37, 17, -32);
                path.cubicTo(12, -35, 8, -37, 7, -34);
                path.lineTo(12, -24);
                path.close();
                paint.setColor(0xffb52337);
                canvas.drawPath(path, paint);
                paint.setColor(0xffdf384f);
                canvas.drawOval(-6, -37, 1, -30, paint);
                paint.setColor(0xffaca3b7);
                canvas.drawRoundRect(-14, -27, 14, -21, 2.5f, 2.5f, paint);
                canvas.drawCircle(17, -32, 4.5f, paint);
                paint.setColor(0xfffff8f1);
                canvas.drawRoundRect(-13, -26.5f, 13, -22, 2, 2, paint);
                canvas.drawCircle(17, -32.5f, 3.6f, paint);
                break;
            case STAR_HAT:
                paint.setColor(0xff39305c);
                canvas.drawRoundRect(-10, -40, 10, -24, 4, 4, paint);
                paint.setColor(0xff64c8c2);
                canvas.drawRect(-9, -29, 9, -25, paint);
                paint.setColor(0xff39305c);
                canvas.drawRoundRect(-14, -25, 14, -21, 2, 2, paint);
                paint.setColor(0xffffd45c);
                path.rewind();
                path.moveTo(0, -39); path.lineTo(1.4f, -35.5f); path.lineTo(5, -35.5f);
                path.lineTo(2.2f, -33.2f); path.lineTo(3.3f, -29.5f); path.lineTo(0, -31.7f);
                path.lineTo(-3.3f, -29.5f); path.lineTo(-2.2f, -33.2f); path.lineTo(-5, -35.5f);
                path.lineTo(-1.4f, -35.5f); path.close();
                canvas.drawPath(path, paint);
                break;
            case RAINBOW_HAT:
                path.rewind();
                path.moveTo(-12, -24);
                path.lineTo(-10, -33);
                path.cubicTo(-8, -44, 8, -44, 10, -33);
                path.lineTo(12, -24);
                path.close();
                canvas.save();
                canvas.clipPath(path);
                int[] stripes = {0xffee5b66, 0xffffa344, 0xffffdc59, 0xff5fc978, 0xff4b9be8, 0xff9b69d8};
                for (int stripe = 0; stripe < stripes.length; stripe++) {
                    paint.setColor(stripes[stripe]);
                    canvas.drawRect(-14, -43 + stripe * 3.2f, 14, -39.8f + stripe * 3.2f, paint);
                }
                canvas.restore();
                paint.setColor(0xff44335e);
                canvas.drawRoundRect(-15, -25, 15, -21, 2, 2, paint);
                break;
            case WITCH_HAT:
                paint.setColor(0xff45305f);
                path.rewind();
                path.moveTo(-13, -23); path.lineTo(-1, -44); path.lineTo(3, -25);
                path.close();
                canvas.drawPath(path, paint);
                paint.setColor(0xff6e4b92);
                canvas.drawRoundRect(-16, -26, 16, -22, 2, 2, paint);
                paint.setColor(0xffffcf59);
                canvas.drawRect(-8, -29, 8, -26, paint);
                break;
            case CLOUD_HAT:
                paint.setColor(0xffc5e8ff);
                canvas.drawCircle(-7, -29, 7, paint);
                canvas.drawCircle(0, -34, 9, paint);
                canvas.drawCircle(8, -29, 7, paint);
                canvas.drawRoundRect(-14, -31, 14, -23, 5, 5, paint);
                paint.setColor(0xff69aee8);
                canvas.drawRoundRect(-15, -25, 15, -21, 2, 2, paint);
                break;
            case GOLD_HAT:
                paint.setColor(0xffffcf55);
                canvas.drawRoundRect(-10, -41, 10, -24, 3, 3, paint);
                paint.setColor(0xffffe79b);
                canvas.drawRect(-9, -35, 9, -31, paint);
                paint.setColor(0xffd18c1c);
                canvas.drawRoundRect(-15, -25, 15, -21, 2, 2, paint);
                paint.setColor(0xffffcf55);
                canvas.drawCircle(0, -43, 3, paint);
                break;
            case BOW_TIE:
                canvas.rotate(-90);
                canvas.translate(0, 3);
                paint.setColor(0xffdb426d);
                path.rewind();
                path.moveTo(-10, 15);
                path.lineTo(0, 19);
                path.lineTo(10, 15);
                path.lineTo(10, 23);
                path.lineTo(0, 19);
                path.lineTo(-10, 23);
                path.close();
                canvas.drawPath(path, paint);
                paint.setColor(0xff9e284c);
                canvas.drawCircle(0, 19, 3, paint);
                break;
            case SUNGLASSES:
                paint.setColor(0xff292538);
                canvas.drawRoundRect(-14, -11, -5, -2, 2.5f, 2.5f, paint);
                canvas.drawRoundRect(-14, 2, -5, 11, 2.5f, 2.5f, paint);
                canvas.drawRect(-11, -3, -9, 3, paint);
                paint.setColor(0xffb4a6d5);
                canvas.drawRoundRect(-12.5f, -9, -8, -7.5f, 1, 1, paint);
                canvas.drawRoundRect(-12.5f, 4, -8, 5.5f, 1, 1, paint);
                break;
            case CROWN:
                paint.setColor(0xffd18c1c);
                path.rewind();
                path.moveTo(-12, -22);
                path.lineTo(-15, -36);
                path.lineTo(-6, -31);
                path.lineTo(0, -41);
                path.lineTo(6, -31);
                path.lineTo(15, -36);
                path.lineTo(12, -22);
                path.close();
                canvas.drawPath(path, paint);
                paint.setColor(0xffffd464);
                canvas.drawRect(-10, -27, 10, -23, paint);
                paint.setColor(0xffbb4f70);
                canvas.drawCircle(0, -29, 3, paint);
                break;
            case FLOWER:
                if (sleeping || startled) canvas.translate(-13, 4);
                else canvas.translate(-17, -5);
                paint.setColor(0xffee89ad);
                for (int petal = 0; petal < 5; petal++) {
                    canvas.drawCircle(0, -4.5f, 3.2f, paint);
                    canvas.rotate(72);
                }
                paint.setColor(0xffffd464);
                canvas.drawCircle(0, 0, 2.5f, paint);
                break;
            case HEADPHONES:
                canvas.rotate(-90);
                paint.setColor(0xff39314d);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(3.5f);
                canvas.drawArc(-27, -31, 27, 24, 180, 180, false, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xff7651de);
                canvas.drawRoundRect(-30.5f, -7, -23, 8, 3, 3, paint);
                canvas.drawRoundRect(23, -7, 30.5f, 8, 3, 3, paint);
                break;
            case SCARF:
                if (sleeping || startled) canvas.rotate(-90);
                paint.setColor(0xffb73757);
                canvas.drawRoundRect(-17, 17, 17, 23, 3, 3, paint);
                path.rewind();
                path.moveTo(5, 20); path.lineTo(11, 20); path.lineTo(9, 30);
                path.lineTo(4, 27); path.close();
                canvas.drawPath(path, paint);
                paint.setColor(0xffff9b9e);
                canvas.drawRoundRect(-15, 18, 15, 20, 1, 1, paint);
                break;
            case HALO:
                if (sleeping || startled) canvas.rotate(-90);
                paint.setColor(0xffffd45c);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f);
                canvas.drawOval(-17, -16, -3, -11, paint);
                paint.setStyle(Paint.Style.FILL);
                break;
            case WINGS:
                for (int wing = 0; wing < 2; wing++) {
                    int side = wing == 0 ? -1 : 1;
                    canvas.save();
                    canvas.scale(side, 1);
                    paint.setColor(0xffbde7ff);
                    canvas.drawOval(18, -7, 29, 2, paint);
                    canvas.drawOval(20, -1, 32, 8, paint);
                    canvas.drawOval(18, 5, 28, 13, paint);
                    paint.setColor(0xffe9f7ff);
                    canvas.drawOval(19, -3, 23, 8, paint);
                    paint.setColor(0xff87c9f2);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(0.8f);
                    canvas.drawOval(18, -7, 29, 2, paint);
                    canvas.drawOval(20, -1, 32, 8, paint);
                    canvas.drawOval(18, 5, 28, 13, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.restore();
                }
                break;
            case BACKPACK:
                paint.setColor(0xff78533e);
                canvas.drawRoundRect(19, 2, 31, 19, 4, 4, paint);
                paint.setColor(0xffd99052);
                canvas.drawRoundRect(21, 7, 29, 14, 2, 2, paint);
                paint.setColor(0xfff3c678);
                canvas.drawCircle(25, 11, 1.5f, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2);
                canvas.drawArc(17, -1, 27, 13, 285, 125, false, paint);
                paint.setStyle(Paint.Style.FILL);
                break;
            case HEART_PIN:
                canvas.save();
                canvas.translate(16, -12);
                paint.setColor(0xffef5d82);
                path.rewind();
                path.moveTo(0, 5);
                path.cubicTo(-11, -2, -5, -9, 0, -4);
                path.cubicTo(5, -9, 11, -2, 0, 5);
                path.close();
                canvas.drawPath(path, paint);
                paint.setColor(0xffffc2d0);
                canvas.drawCircle(-2, -3, 1.4f, paint);
                canvas.restore();
                break;
            case NONE:
                break;
        }
        canvas.restore();
    }
}
